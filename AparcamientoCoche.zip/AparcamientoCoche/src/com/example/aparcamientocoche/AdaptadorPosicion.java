package com.example.aparcamientocoche;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.aparcamientocoche.model.Posicion;

public class AdaptadorPosicion extends ArrayAdapter<Posicion> {
	private List<Posicion> items;
	private Context context;

	public AdaptadorPosicion(Context context, int disenyoPorFila,List<Posicion> locales) {
		super(context, disenyoPorFila, locales);
		this.items = locales;
		this.context = context;
	}

	@Override
	public long getItemId(int position){
		return items.get(position).getId();
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View v = convertView;
		if (v == null) {
			LayoutInflater vi = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			v = vi.inflate(R.layout.posicion_item, null);
		}
		Posicion o = items.get(position);
		if (o != null) {
			
			TextView tv_id = (TextView) v.findViewById(R.id.tv_id);
			tv_id.setText("Cod: "+o.getId());
			
			TextView tv_fecha = (TextView) v.findViewById(R.id.tv_fecha);
			tv_fecha.setText("Fecha: "+o.getFecha());
			
			TextView tv_direccion = (TextView) v.findViewById(R.id.tv_direccion);
			tv_direccion.setText(o.getDireccion());
			tv_direccion.setSelected(true);
			
		}
		return v;
	}
}
