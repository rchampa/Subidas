package com.example.aparcamientocoche;

import android.location.Location;

public interface NuevaPosicionListener {
	
	public void nuevaPosicion(Location nueva_posicion);

}
