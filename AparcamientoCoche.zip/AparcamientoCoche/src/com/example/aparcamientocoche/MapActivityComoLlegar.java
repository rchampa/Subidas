package com.example.aparcamientocoche;

import android.os.Bundle;
import android.util.Log;

import com.example.aparcamientocoche.dao.PosicionDAO;
import com.example.aparcamientocoche.model.Posicion;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;

public class MapActivityComoLlegar extends  android.support.v4.app.FragmentActivity {
	
	GoogleMap map;
	Posicion posicion;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map);
		
		setUpMapIfNeeded();
		
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			
			PosicionDAO dao = new PosicionDAO();
		    int id = Integer.parseInt(""+extras.get("ID"));
		    posicion =  dao.get(id);
		    moverCamara(posicion.getLatitud(), posicion.getLongitud());
		}

		
//		Marker myMaker = mapa.addMarker(new MarkerOptions()
//		.title("Coche")
//		.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
//		.position(new LatLng(latAnt, longAnt)));
//		
//		Polyline line = mapa.addPolyline(new PolylineOptions()
//	    .add(new LatLng(latAnt, longAnt), new LatLng(latAct, longAct))
//	    .width(5)
//	    .color(Color.BLACK));
	}
	
	private void setUpMapIfNeeded() {
        if (map == null) {

            Log.e("", "Into null map");
            map = ((SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map)).getMap();


            if (map != null) {
                Log.e("", "Into full map");
                map.setMyLocationEnabled(true);
                map.getUiSettings().setZoomControlsEnabled(false);
            }
        }
    }

	
	private void moverCamara(double latitud, double longitud) {
		
		LatLng madrid = new LatLng(latitud, longitud);
        CameraPosition camPos = new CameraPosition.Builder()
                    .target(madrid)   //Center camera in 'Plaza Maestro Villa'
                    .zoom(15)         //Set 19 level zoom
                    .bearing(0)      //Set the orientation to northeast
                    .tilt(0)         //Set 70 degrees tilt
                    .build();
        
        CameraUpdate camUpd3 = CameraUpdateFactory.newCameraPosition(camPos);
        map.animateCamera(camUpd3);
		
	}
	
	
	
	
	
	
//	public class MapaUpdaterReceiver extends BroadcastReceiver{
//
//		@Override
//		public void onReceive(Context arg0, Intent arg1) {
//			locListener = new LocationListener() {
//			    public void onLocationChanged(Location location) {
//			    	Bundle extras=getIntent().getExtras();
//			    	String latitud = extras.getString("latitud");
//					String longitud = extras.getString("longitud");
//					Double latAnt=Double.parseDouble(latitud);
//					Double longAnt=Double.parseDouble(longitud);
//			    	Double latAct=location.getLatitude();
//					Double longAct=location.getLongitude();
//					
//			    	mapa.clear();
//			    	
//			    	Marker myMaker = mapa.addMarker(new MarkerOptions()
//					.title("Coche")
//					.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
//					.position(new LatLng(latAnt, longAnt)));
//			    	
//					Polyline line = mapa.addPolyline(new PolylineOptions()
//				    .add(new LatLng(latAnt, longAnt), new LatLng(latAct, longAct))
//				    .width(5)
//				    .color(Color.BLACK));
//			    }
//			    
//			    public void onStatusChanged(String provider, int status, Bundle extras){
//			    }
//
//				@Override
//				public void onProviderDisabled(String provider) {
//					// TODO Auto-generated method stub	
//				}
//
//				@Override
//				public void onProviderEnabled(String provider) {
//					// TODO Auto-generated method stub	
//				}	
//			};
//			locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500,2,locListener);
//			locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500,2,locListener);
//		}
//	}
}
