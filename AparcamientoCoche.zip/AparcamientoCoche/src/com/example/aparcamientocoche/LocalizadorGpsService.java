package com.example.aparcamientocoche;

import java.util.List;

import com.example.aparcamientocoche.dao.DatabaseHelper;
import com.example.aparcamientocoche.dao.PosicionDAO;

import android.app.AlertDialog;
import android.app.IntentService;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class LocalizadorGpsService extends IntentService {
	private static final String TAG = null;
	private LocationManager locManager;
	private LocationListener locListener;
	private SQLiteDatabase db;
	private DatabaseHelper dbHelper;

	public LocalizadorGpsService() {
		super("LocalizadorGpsService");
	}
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		db=MainActivity.db;
		Toast.makeText(this,"construyendo servicio", 2).show();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		Toast.makeText(LocalizadorGpsService.this,"arrancando servicio", 2).show();
		locListener = new LocationListener() { 
		    public void onLocationChanged(Location location) {
		    	Toast.makeText(LocalizadorGpsService.this,"obteniendo posicion", 2).show();
		        guardarPosicion(location);
		        Toast.makeText(LocalizadorGpsService.this,"posicion guardada", 2).show();
		        locManager.removeUpdates(this);
		    }
		    
		    public void onStatusChanged(String provider, int status, Bundle extras){
		    }

			@Override
			public void onProviderDisabled(String provider) {
				// TODO Auto-generated method stub	
			}

			@Override
			public void onProviderEnabled(String provider) {
				// TODO Auto-generated method stub	
			}	
		};
		locManager = (LocationManager)getSystemService(LOCATION_SERVICE);
		locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500,0,locListener);
		locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500,0,locListener);
		if (!locManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
			mostrarAvisoGpsDeshabilitado();
		}
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void onHandleIntent(Intent intent) {
	}
	
    private void guardarPosicion(Location loc) {
    	if(loc != null){
          String latitud=(String.valueOf(loc.getLatitude()));
          String longitud=(String.valueOf(loc.getLongitude()));
          ContentValues values = new ContentValues();
		  values.put(PosicionDAO.COLUMN_LATITUD, latitud);
		  values.put(PosicionDAO.COLUMN_LONGITUD, longitud);
		  db.insert(PosicionDAO.TABLE_POSICIONES, null,values);
		  Toast.makeText(LocalizadorGpsService.this, "Localizacion guardada correctamente", 4).show();
        }else{
        	Toast.makeText(LocalizadorGpsService.this, "No se ha guardado ninguna localizaci�n", 4).show();
        }
        
	}
    
    

	private void mostrarAvisoGpsDeshabilitado() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("El GPS esta deshabilitado!")
               .setCancelable(false)
               .setPositiveButton("Habilitar", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                       launchGPSOptions();
                   }
               })
               .setNegativeButton("No hacer nada", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        // mostrar notificaci�n
                        Toast.makeText(getApplicationContext(), "El GPS est� deshabilitado", Toast.LENGTH_LONG).show();
                   }
               });
        AlertDialog alert = builder.create();  
        alert.show();
        }
    
    private void launchGPSOptions() {
        Log.d(TAG, "Lanzando configuraci�n de localizaci�n");
        Intent gpsOptionsIntent = new Intent(  
                android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);  
        this.startActivity(gpsOptionsIntent);
    }  
	


}
