package com.example.aparcamientocoche.model;

public class Posicion {
	private int id;
	private double latitud;
	private double longitud;
	private String direccion;
	private String fecha;
	

	public Posicion(int id, double latitud, double longitud, String direccion, String fecha) {
		this.id = id;
		this.latitud = latitud;
		this.longitud = longitud;
		this.direccion = direccion;
		this.fecha = fecha;
	}
	
	public Posicion(double latitud, double longitud, String direccion, String fecha) {
		this.latitud = latitud;
		this.longitud = longitud;
		this.direccion = direccion;
		this.fecha = fecha;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public double getLatitud() {
		return latitud;
	}


	public void setLatitud(double latitud) {
		this.latitud = latitud;
	}


	public double getLongitud() {
		return longitud;
	}


	public void setLongitud(double longitud) {
		this.longitud = longitud;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	public String getFecha() {
		return fecha;
	}


	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	

}
