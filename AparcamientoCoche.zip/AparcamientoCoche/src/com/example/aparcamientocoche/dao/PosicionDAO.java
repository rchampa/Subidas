package com.example.aparcamientocoche.dao;

import java.util.ArrayList;

import com.example.aparcamientocoche.model.Posicion;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class PosicionDAO {

	public static final String TABLE_POSICIONES = "Posiciones";
	public static final String COLUMN_ID = "_id";
	public static final String COLUMN_ADDRESS = "direccion";
	public static final String COLUMN_DATE = "fecha";
	public static final String COLUMN_LATITUD = "latitud";
	public static final String COLUMN_LONGITUD = "longitud";

	public ArrayList<Posicion> getAllPosiciones() {

		ArrayList<Posicion> list = new ArrayList<Posicion>();
		SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
		Cursor cursor = db.query(TABLE_POSICIONES, null, null, null, null,
				null, null);

		if (cursor.moveToFirst()) {

			Posicion posicion;
			do {
				int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
				String address = cursor.getString(cursor
						.getColumnIndex(COLUMN_ADDRESS));
				String fecha = cursor.getString(cursor
						.getColumnIndex(COLUMN_DATE));
				double latitude = cursor.getDouble(cursor
						.getColumnIndex(COLUMN_LATITUD));
				double longitude = cursor.getDouble(cursor
						.getColumnIndex(COLUMN_LONGITUD));
				posicion = new Posicion(id, latitude, longitude, address, fecha);
				list.add(posicion);
			} while (cursor.moveToNext());
		}

		cursor.close();
		db.close();
		return list;
	}

	public Posicion get(int id) {
		SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
		Cursor cursor = db.query(TABLE_POSICIONES, null, COLUMN_ID + "=?",
				new String[] { "" + id }, null, null, null);
		Posicion posicion = null;
		if (cursor.moveToFirst()) {
			String address = cursor.getString(cursor
					.getColumnIndex(COLUMN_ADDRESS));
			String fecha = cursor.getString(cursor.getColumnIndex(COLUMN_DATE));
			double latitude = cursor.getDouble(cursor
					.getColumnIndex(COLUMN_LATITUD));
			double longitude = cursor.getDouble(cursor
					.getColumnIndex(COLUMN_LONGITUD));
			posicion = new Posicion(id, latitude, longitude, address, fecha);

		}

		cursor.close();
		db.close();
		return posicion;
	}

	public long insert(Posicion posicion) {
		SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(COLUMN_ADDRESS, posicion.getDireccion());
		values.put(COLUMN_DATE, posicion.getFecha());
		values.put(COLUMN_LATITUD, posicion.getLatitud());
		values.put(COLUMN_LONGITUD, posicion.getLongitud());
		long num = db.insert(TABLE_POSICIONES, null, values);
		db.close();
		return num;
	}

	// public int update(Friend friend) {
	// SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
	// ContentValues values = new ContentValues();
	// values.put(NAME, friend.getUserName());
	// values.put(STATE, friend.getState().ordinal());
	// int num = db.update(TABLE, values, NAME + "=?", new
	// String[]{friend.getUserName()});
	//
	// db.close();
	// return num;
	// }

	// public void delete(String name) {
	// SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
	// db.delete(TABLE, NAME+"=?", new String[]{name});
	// db.close();
	// }
	//
	// public void delete(Friend friend) {
	// delete(friend.getUserName());
	// }
	//
	// public void deleteAll() {
	// SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
	// db.delete(TABLE, null, null);
	// db.close();
	// }

}
