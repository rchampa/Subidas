package com.example.aparcamientocoche.dao;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.aparcamientocoche.MyApp;

public class DatabaseHelper extends SQLiteOpenHelper{
	
	private static final String DATABASE_NAME = "Posicines.db";
	private static final int DATABASE_VERSION = 1;
	//public static final String[] columns={COLUMN_ID};

	public DatabaseHelper() {
		super(MyApp.getContext(),DATABASE_NAME,null,DATABASE_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("create table " + PosicionDAO.TABLE_POSICIONES + " (" + PosicionDAO.COLUMN_ID
				+ " integer primary key autoincrement," 
				+ PosicionDAO.COLUMN_ADDRESS + " text,"
				+ PosicionDAO.COLUMN_DATE + " text,"
				+ PosicionDAO.COLUMN_LATITUD + " double,"
				+ PosicionDAO.COLUMN_LONGITUD + " double)");	
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS " + PosicionDAO.TABLE_POSICIONES);
		onCreate(db);
		
	}
	

}
