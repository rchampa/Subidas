package com.example.aparcamientocoche;

import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.aparcamientocoche.dao.PosicionDAO;
import com.example.aparcamientocoche.model.Posicion;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;

public class MapActivity extends  android.support.v4.app.FragmentActivity
implements NuevaPosicionListener{
	
	GoogleMap map;
	MyTracker tracker;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map);
		
		setUpMapIfNeeded();
		
		tracker = new MyTracker(this.getApplicationContext());
		tracker.setListener(this);
		
		
//		Marker myMaker = mapa.addMarker(new MarkerOptions()
//		.title("Coche")
//		.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
//		.position(new LatLng(latAnt, longAnt)));
//		
//		Polyline line = mapa.addPolyline(new PolylineOptions()
//	    .add(new LatLng(latAnt, longAnt), new LatLng(latAct, longAct))
//	    .width(5)
//	    .color(Color.BLACK));
	}
	
	
	@Override
	protected void onStart(){
		super.onStart();
		tracker.encender();
	}
	
	@Override
	protected void onStop(){
		tracker.apagar();
		super.onStop();
	}
	
	
	private void setUpMapIfNeeded() {
        if (map == null) {

            Log.e("", "Into null map");
            map = ((SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map)).getMap();


            if (map != null) {
                Log.e("", "Into full map");
                map.setMyLocationEnabled(true);
                map.getUiSettings().setZoomControlsEnabled(false);
            }
        }
    }

	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
            getMenuInflater().inflate(R.menu.menu_mapa, menu);
            return true;
    }
	
	@Override
    public boolean onOptionsItemSelected(MenuItem item) 
    {        
        switch(item.getItemId())
        {
            case R.id.menu_guardar:
            	
            	Calendar c = GregorianCalendar.getInstance(); 
            	
            	int seconds = c.get(GregorianCalendar.SECOND);
            	int minutes = c.get(GregorianCalendar.MINUTE);
            	int hours = c.get(GregorianCalendar.HOUR_OF_DAY);
            	
            	int day = c.get(GregorianCalendar.DAY_OF_MONTH);
            	int month =c.get(GregorianCalendar.MONTH)+1;//Enero=0
            	int year = c.get(GregorianCalendar.YEAR);
            	
            	String fecha = ""+day+"/"+month+"/"+year+" "+hours+":"+minutes+":"+seconds;
            	
            	Geocoder geocoder;
            	List<Address> addresses=null;
            	geocoder = new Geocoder(this, Locale.getDefault());
            	Location posicion_actual = tracker.getCurrentLocation();
            	String direccion =null;
				try {
					addresses = geocoder.getFromLocation(posicion_actual.getLatitude(), posicion_actual.getLongitude(), 1);
					if(addresses==null || addresses.size()==0){
						Toast.makeText(this, "Imposible encontrar la dirección actual", Toast.LENGTH_SHORT).show();
						return true;
					}
					
					Address a = addresses.get(0);
	            	direccion = a.getThoroughfare()+" "+a.getSubThoroughfare()+", "+a.getLocality()+", "+a.getCountryName();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				
            	
            	Posicion posicion = new Posicion(posicion_actual.getLatitude(), posicion_actual.getLongitude(), direccion, fecha);
            	
            	PosicionDAO dao = new PosicionDAO();
            	dao.insert(posicion);
            	finish();
				break;
        }
        
		return true;
    }

	@Override
	public void nuevaPosicion(Location nueva_posicion) {
		
		LatLng madrid = new LatLng(nueva_posicion.getLatitude(), nueva_posicion.getLongitude());
        CameraPosition camPos = new CameraPosition.Builder()
                    .target(madrid)   //Center camera in 'Plaza Maestro Villa'
                    .zoom(15)         //Set 19 level zoom
                    .bearing(0)      //Set the orientation to northeast
                    .tilt(0)         //Set 70 degrees tilt
                    .build();
        
        CameraUpdate camUpd3 = CameraUpdateFactory.newCameraPosition(camPos);
        map.animateCamera(camUpd3);
		
	}
	
	
	
	
	
	
//	public class MapaUpdaterReceiver extends BroadcastReceiver{
//
//		@Override
//		public void onReceive(Context arg0, Intent arg1) {
//			locListener = new LocationListener() {
//			    public void onLocationChanged(Location location) {
//			    	Bundle extras=getIntent().getExtras();
//			    	String latitud = extras.getString("latitud");
//					String longitud = extras.getString("longitud");
//					Double latAnt=Double.parseDouble(latitud);
//					Double longAnt=Double.parseDouble(longitud);
//			    	Double latAct=location.getLatitude();
//					Double longAct=location.getLongitude();
//					
//			    	mapa.clear();
//			    	
//			    	Marker myMaker = mapa.addMarker(new MarkerOptions()
//					.title("Coche")
//					.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
//					.position(new LatLng(latAnt, longAnt)));
//			    	
//					Polyline line = mapa.addPolyline(new PolylineOptions()
//				    .add(new LatLng(latAnt, longAnt), new LatLng(latAct, longAct))
//				    .width(5)
//				    .color(Color.BLACK));
//			    }
//			    
//			    public void onStatusChanged(String provider, int status, Bundle extras){
//			    }
//
//				@Override
//				public void onProviderDisabled(String provider) {
//					// TODO Auto-generated method stub	
//				}
//
//				@Override
//				public void onProviderEnabled(String provider) {
//					// TODO Auto-generated method stub	
//				}	
//			};
//			locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500,2,locListener);
//			locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500,2,locListener);
//		}
//	}
}
