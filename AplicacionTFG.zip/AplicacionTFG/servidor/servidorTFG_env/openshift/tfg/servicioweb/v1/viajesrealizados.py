# -*- encoding: utf-8 -*-
from myglobal import app,db,api,auth

from flask import session, make_response, jsonify, abort
from flask.views import MethodView
from flask.ext.restful import Api, Resource, reqparse, fields, marshal
#import json,ast

from datetime import datetime 
from models import ViajeFuturo, Participante, Usuario,Amigos
from formatOutputMessage import formatOutput
   
#'actualizado_en': datetime.strptime("2014-11-30 10:30:00","%Y-%m-%d %H:%M:%S"), 

viaje_fields = {
    'id_viaje': fields.Integer,
    'nombre': fields.String,
    'fecha_ini': fields.DateTime(dt_format='iso8601'),
    'duracion': fields.Integer,
    'categoria': fields.Integer,
    'pais': fields.String,
    'latitud': fields.Float,
    'longitud': fields.Float,
    'realizado': fields.Boolean
}


class ViajesRealizados(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('id_viaje', type = str, required = True, help = 'Falta el parametro nombre', location = 'json')
        self.reqparse.add_argument('realizado', type = bool, required = True, help = 'Falta el parametro realizado', location = 'json')
        super(ViajesRealizados, self).__init__()


    def get(self):
        from flask import request
        arg_id_usuario = request.args.get('id_usuario')
        if (arg_id_usuario is not None):
            arg_id_usuario = int(arg_id_usuario)
            lista_viajes_ids = Participante.query.filter_by(id_usuario=arg_id_usuario).all()
            lista = []
            for fila in lista_viajes_ids:
                lista.append(fila.id_viaje)

            lista_viajes = ViajeFuturo.query.filter( ViajeFuturo.id_viaje.in_(lista) , ViajeFuturo.realizado==True).all()
            content = { 'viajes': map(lambda t: marshal(t, viaje_fields), lista_viajes) }
            return formatOutput(5000, content), 200
        else:#el usuario no existe
            return formatOutput(5004), 200
        
    #marca un viaje como realizado o No realizado
    def post(self):
        args = self.reqparse.parse_args()

        viaje = ViajeFuturo.query.filter_by(id_viaje=args['id_viaje']).first()

        if viaje is None:
            return formatOutput(5003), 200

        esRealizado = args['realizado']

        if esRealizado:
            viaje.realizado = True
            db.session.add(viaje)
            db.session.commit()

            content = { 'viaje': marshal(viaje,viaje_fields)}
            return formatOutput(5001), 201
        else:
            viaje.realizado = False
            db.session.add(viaje)
            db.session.commit()
            return formatOutput(5002), 201



api.add_resource(ViajesRealizados, '/tfg/api/v1.0/viajesrealizados', endpoint = 'viajesrealizados')





