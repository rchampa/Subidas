from myglobal import db
from werkzeug import generate_password_hash, check_password_hash
import json
import datetime

def to_json(inst, cls):
    """
    Jsonify the sql alchemy query result.
    """
    convert = dict()
    # add your coversions for things like datetime's 
    # and what-not that aren't serializable.
    d = dict()
    for c in cls.__table__.columns:
        v = getattr(inst, c.name)
        if type(v) is datetime.datetime:
          v = str(v)

        if c.type in convert.keys() and v is not None:
            try:
                d[c.name] = convert[c.type](v)
            except:
                d[c.name] = "Error:  Failed to covert using ", str(convert[c.type])
        elif v is None:
            d[c.name] = str()
        else:
            d[c.name] = v
    return json.dumps(d)


class Administrador(db.Model):
  __tablename__ = 'administradores'
  email = db.Column(db.String(15), primary_key = True)
  password_hash = db.Column(db.String(54))
  creado_en = db.Column(db.DateTime)
  actualizado_en = db.Column(db.DateTime)
  ultima_conexion = db.Column(db.DateTime)

   
  def __init__(self, email, new_password):
    self.email = email
    self.set_password(new_password)
     
  def set_password(self, new_password):
    self.password_hash = generate_password_hash(new_password)
   
  def check_password(self, new_password):
    return check_password_hash(self.password_hash, new_password)

  @property
  def json(self):
    return to_json(self, self.__class__)


class Usuario(db.Model):
  __tablename__ = 'usuarios'
  id_usuario = db.Column(db.Integer, primary_key = True)
  nombre_usuario = db.Column(db.String)
  password_usuario = db.Column(db.String)
  fecha_nacimiento = db.Column(db.DateTime)
  ultima_conexion = db.Column(db.DateTime)
  creado_en = db.Column(db.DateTime)
  actualizado_en = db.Column(db.DateTime)
  #participantes que viene de la tabla Participante
   
  def __init__(self, nombre_usuario, password_usuario):
    self.nombre_usuario = nombre_usuario
    self.password_usuario = password_usuario
    #self.fecha_nacimiento = fecha_nacimiento
    dtutcnow = datetime.datetime.utcnow()
    self.creado_en = dtutcnow

  @property
  def json(self):
    return to_json(self, self.__class__)



class ViajeFuturo(db.Model):
  __tablename__ = 'viajes_futuros'
  id_viaje = db.Column(db.Integer, primary_key = True)
  nombre = db.Column(db.String(40))
  fecha_ini = db.Column(db.DateTime)
  duracion = db.Column(db.Integer)
  categoria = db.Column(db.Integer)
  pais = db.Column(db.String(40))
  latitud = db.Column(db.Float)
  longitud = db.Column(db.Float)
  #participantes que viene de la tabla Participante

  #def __init__(self, nombre,fecha_ini,duracion,categoria,pais,latitud,longitud):
  def __init__(self, nombre,duracion,categoria,pais,latitud,longitud):
    self.nombre = nombre
    #self.fecha_ini = fecha_ini
    self.duracion = duracion
    self.categoria = categoria
    self.pais = pais
    self.latitud = latitud
    self.longitud = longitud

  @property
  def json(self):
    return to_json(self, self.__class__)



class Participante(db.Model):
  __tablename__ = 'participantes'
  id_viaje = db.Column(db.Integer, db.ForeignKey('viajes_futuros.id_viaje'), primary_key = True)
  id_usuario = db.Column(db.Integer, db.ForeignKey('usuarios.id_usuario'), primary_key = True)
  usuario = db.relationship('Usuario', backref=db.backref('participantes', lazy='dynamic'))
  viaje = db.relationship('ViajeFuturo', backref=db.backref('participantes', lazy='dynamic'))

   
  def __init__(self, usuario, viaje):
    self.usuario = usuario
    self.viaje = viaje

  @property
  def json(self):
    return to_json(self, self.__class__)



