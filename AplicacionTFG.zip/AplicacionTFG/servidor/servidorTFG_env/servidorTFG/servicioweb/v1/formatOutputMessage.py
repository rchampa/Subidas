# -*- encoding: utf-8 -*-

#{code: 1003, ok: true o false, message:"un mensaje", content:{un objeto json}}
def formatOutput(code, content=None):

    messages =  {
                    1000:"Lista de usuarios",
                    1001:"Registro de usuario correcto",
                    1002:"Datos del usuario",
                    1003:"El usuario no existe",
                    1004:"El usuario o la contraseña no son correctos",
                    


                    2000:"Lista de viajes",
                    2001:"Registro de viaje correcto",
                    2002:"Datos del viaje",
                    2003:"El viaje no está registrado",
                    2004:"",
                    2005:"s",

                    
                }

    return {
            'code': code,
            'message': messages[code],
            'content':content
            }