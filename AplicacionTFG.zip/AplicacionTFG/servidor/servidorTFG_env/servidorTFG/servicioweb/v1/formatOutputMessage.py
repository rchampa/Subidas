# -*- encoding: utf-8 -*-

#{code: 1003, ok: true o false, message:"un mensaje", content:{un objeto json}}
def formatOutput(code, content=None):

    messages =  {
                    1000:"Lista de usuarios",
                    1001:"Registro de usuario correcto",
                    1002:"Datos del usuario",
                    1003:"El usuario no existe",
                    1004:"El usuario o la contraseña no son correctos",
                    


                    2000:"Lista de viajes",
                    2001:"Registro de viaje correcto",
                    2002:"Datos del viaje",
                    2003:"El viaje no está registrado",
                    2004:"Lista de viajes de amigos del usuario",
                    2005:"Lista de viajes del usuario",


                    3000:"Lista de todas las amistades de todo el mundo",
                    3001:"Alta de nueva relación de amistad",
                    3002:"Datos de relación de amistad",
                    3003:"La relación de amistad no existe",
                    3004:"Lista de amigos del usuario",
                    3005:"El usuario no tiene amigos",


                    4000:"Nuevo participante añadido al viaje",
                    4001:""
                    
                    
                }

    return {
            'code': code,
            'message': messages[code],
            'content':content
            }