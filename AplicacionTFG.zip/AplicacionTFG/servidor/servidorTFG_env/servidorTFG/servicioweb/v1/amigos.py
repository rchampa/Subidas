# -*- encoding: utf-8 -*-
from myglobal import app,db,api,auth

from flask import session, make_response, jsonify, abort
from flask.views import MethodView
from flask.ext.restful import Api, Resource, reqparse, fields, marshal
#import json,ast

from datetime import datetime 
from models import Amigos
from formatOutputMessage import formatOutput
   
#'actualizado_en': datetime.strptime("2014-11-30 10:30:00","%Y-%m-%d %H:%M:%S"), 


#users = []
 
amigos_fields = {
    'id_amistad': fields.Integer,
    'id_amigo1': fields.Integer,
    'id_amigo2': fields.Integer
}


class AmigoListAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('id_amigo1', type = int, required = True, help = 'Falta el parametro id_amigo1', location = 'json')
        self.reqparse.add_argument('id_amigo2', type = int, required = True, help = 'Falta el parametro id_amigo2', location = 'json')
        self.reqparse.add_argument('tipo', type = bool, required = True, help = 'Falta el parametro tipo', location = 'json')
        super(AmigoListAPI, self).__init__()
        
    def get(self):
        lista_amistades = Amigos.query.all()
        content = { 'amistades': map(lambda t: marshal(t, amigos_fields), lista_amistades) }
        return formatOutput(3000, content), 200

    def post(self):
        args = self.reqparse.parse_args()

        nuevo_amistad = Amigos(args['id_amigo1'], args['id_amigo2'])
        db.session.add(nuevo_amistad)
        db.session.commit()

        content = { 'amistades': marshal(nuevo_amistad,amigos_fields)}
        return formatOutput(3001, content), 201

    
            

class AmigoAPI(Resource):
    decorators = [auth.login_required]
    
    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        #self.reqparse.add_argument('gcm_id', type = str, required = True, help = 'No gcm_id provided', location = 'json')
        super(AmigoAPI, self).__init__()

    def get(self, id):
        amigos_de = Amigos.query.filter((Amigos.id_amigo1 == id) | (Amigos.id_amigo2 == id))
        if amigos_de is None:
            return formatOutput(3005),200
        else:
            content = { 'amistades': map(lambda t: marshal(t, amigos_fields), amigos_de) }
            return formatOutput(3004, content), 200
        
    def put(self, id):
        user = filter(lambda t: t['id_usuario'] == id, users)
        if len(user) == 0:
            abort(404)
        user = user[0]
        args = self.reqparse.parse_args()
        for k, v in args.iteritems():
            if v != None:
                user[k] = v

        return { 'user': marshal(user, user_fields) }

    def delete(self, id):
        user = filter(lambda t: t['id_usuario'] == id, users)
        if len(user) == 0:
            abort(404)
        users.remove(user[0])
        return { 'result': True }




api.add_resource(AmigoListAPI, '/tfg/api/v1.0/friendships', endpoint = 'friendships')
api.add_resource(AmigoAPI, '/tfg/api/v1.0/friendships/<int:id>', endpoint = 'friendship')

