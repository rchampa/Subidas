# -*- encoding: utf-8 -*-
from myglobal import app,db,api,auth
#from sqlalchemy import and_ 
from flask import session, make_response, jsonify, abort
from flask.views import MethodView
from flask.ext.restful import Api, Resource, reqparse, fields, marshal
#import json,ast

from datetime import datetime 
from models import Usuario, Dispositivo, RelDispositivoUsuario
from formatOutputMessage import formatOutput
   
#'actualizado_en': datetime.strptime("2014-11-30 10:30:00","%Y-%m-%d %H:%M:%S"), 


users = []
 
user_fields = {
    'id_usuario': fields.Integer,
    'id_centro': fields.Integer,
    'creado_en': fields.DateTime(dt_format='iso8601'),
    'actualizado_en': fields.DateTime(dt_format='iso8601'),
    'uri': fields.Url('users')
}


class UserListAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('id_usuario', type = int, required = True, help = 'No id_usuario provided', location = 'json')
        self.reqparse.add_argument('id_centro', type = int, required = True, help = 'No id_centro provided', location = 'json')
        self.reqparse.add_argument('id_dispositivo', type = int, required = True, help = 'No id_centro provided', location = 'json')
        super(UserListAPI, self).__init__()
        
    def get(self):
        lista_usuarios = Usuario.query.all()
        content = { 'users': map(lambda t: marshal(t, user_fields), lista_usuarios) }
        return formatOutput(1000,True, content), 200

    def post(self):
        args = self.reqparse.parse_args()
        user = Usuario.query.filter_by(id_usuario=args['id_usuario']).first()
        
        if user is None:
            new_user = Usuario(args['id_usuario'], args['id_centro'])
            db.session.add(new_user)
            return self.__nuevoUsuario(new_user,args['id_dispositivo'])
        else:
            return self.__usuarioExistente(user, args['id_dispositivo'])


    def __nuevoUsuario(self, new_user, id_dispositivo):
        
        device = Dispositivo.query.filter_by(id_dispositivo=id_dispositivo).first()

        #Siempre se debe enviar un id_dispositivo
        if device is None:
            return formatOutput(1001,False), 200
        else:
            new_rel = RelDispositivoUsuario(device, new_user)
            db.session.add(new_rel)
            db.session.commit()
            content = {'user': marshal(new_user, user_fields)}
            return formatOutput(1002,True,content), 201

    def __usuarioExistente(self, usuario, id_dispositivo):
        device = Dispositivo.query.filter_by(id_dispositivo=id_dispositivo).first()

        #Siempre se debe enviar un id_dispositivo
        if device is None:
            return formatOutput(1001,False), 200
        else:

            dispositivo_buscado = self.__buscarDispositivo(usuario.dispositivos.all(),id_dispositivo)

            if dispositivo_buscado is not None:# si existe

                if dispositivo_buscado.activo:
                    content =   {
                                'rel_id':dispositivo_buscado.id,
                                'user': marshal(dispositivo_buscado.usuario, user_fields),
                                'device':marshal(dispositivo_buscado.dispositivo, device_fields),
                                }
                    return formatOutput(1003,True,content), 200
                else:
                    new_rel = RelDispositivoUsuario(device, usuario)
                    db.session.add(new_rel)
                    db.session.commit()
                    content =   {
                                'user': marshal(new_rel.usuario, user_fields),
                                'device':marshal(new_rel.dispositivo, device_fields),
                                }
                    return formatOutput(1004,True,content), 201
            else:
                new_rel = RelDispositivoUsuario(device, usuario)
                db.session.add(new_rel)
                db.session.commit()
                content =   {
                            'user': marshal(new_rel.usuario, user_fields),
                            'device':marshal(new_rel.dispositivo, device_fields),
                            }
                return formatOutput(1005,True,content), 201

            

    def __buscarDispositivo(self, lista_dispositivos, id_dispositivo):

        if not lista_dispositivos:
            return None

        for dispositivo in lista_dispositivos:
            if dispositivo.id_dispositivo == id_dispositivo and dispositivo.activo:
                return dispositivo
            

class UserAPI(Resource):
    decorators = [auth.login_required]
    
    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('gcm_id', type = str, required = True, help = 'No gcm_id provided', location = 'json')
        super(UserAPI, self).__init__()

    def get(self, id):
        user = Usuario.query.filter_by(id_usuario=id).first()
        if user is not None:
            content = { 'user': marshal(user, user_fields) }
            return formatOutput(1100,True,content),200
        else:
            return formatOutput(1101, True), 200
        
    def put(self, id):
        user = filter(lambda t: t['id_usuario'] == id, users)
        if len(user) == 0:
            abort(404)
        user = user[0]
        args = self.reqparse.parse_args()
        for k, v in args.iteritems():
            if v != None:
                user[k] = v

        return { 'user': marshal(user, user_fields) }

    def delete(self, id):
        user = filter(lambda t: t['id_usuario'] == id, users)
        if len(user) == 0:
            abort(404)
        users.remove(user[0])
        return { 'result': True }


api.add_resource(UserListAPI, '/scheduler/api/v1.0/users', endpoint = 'users')
api.add_resource(UserAPI, '/scheduler/api/v1.0/users/<int:id>', endpoint = 'user')
