# -*- encoding: utf-8 -*-
from myglobal import app,db,api,auth

from flask import session, make_response, jsonify, abort
from flask.views import MethodView
from flask.ext.restful import Api, Resource, reqparse, fields, marshal
#import json,ast

from datetime import datetime 
from models import Usuario
from formatOutputMessage import formatOutput
   
#'actualizado_en': datetime.strptime("2014-11-30 10:30:00","%Y-%m-%d %H:%M:%S"), 


#users = []
 
user_fields = {
    'id_usuario': fields.Integer,
    'nombre_usuario': fields.String,
    'fecha_nacimiento': fields.DateTime(dt_format='iso8601'),
    'creado_en': fields.DateTime(dt_format='iso8601')
}


class UserListAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('nombre_usuario', type = str, required = True, help = 'Falta el parametro nombre_usuario', location = 'json')
        self.reqparse.add_argument('password_usuario', type = str, required = True, help = 'Falta el parametro password_usuario', location = 'json')
        #self.reqparse.add_argument('fecha_nacimiento', type = datetime, required = True, help = 'Falta el parametro fecha_nacimiento', location = 'json')
        super(UserListAPI, self).__init__()
        
    def get(self):
        lista_usuarios = Usuario.query.all()
        content = { 'users': map(lambda t: marshal(t, user_fields), lista_usuarios) }
        return formatOutput(1000, content), 200

    def post(self):
        args = self.reqparse.parse_args()

        nuevo_usuario = Usuario(args['nombre_usuario'], args['password_usuario'])
        db.session.add(nuevo_usuario)
        db.session.commit()
        content = { 'user': marshal(nuevo_usuario,user_fields)}
        return formatOutput(1001, content), 201

    
            

class UserAPI(Resource):
    decorators = [auth.login_required]
    
    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        #self.reqparse.add_argument('gcm_id', type = str, required = True, help = 'No gcm_id provided', location = 'json')
        super(UserAPI, self).__init__()

    def get(self, id):
        user = Usuario.query.filter_by(id_usuario=id).first()
        if user is not None:
            content = { 'user': marshal(user, user_fields) }
            return formatOutput(1002,content),200
        else:
            return formatOutput(1003), 200
        
    def put(self, id):
        user = filter(lambda t: t['id_usuario'] == id, users)
        if len(user) == 0:
            abort(404)
        user = user[0]
        args = self.reqparse.parse_args()
        for k, v in args.iteritems():
            if v != None:
                user[k] = v

        return { 'user': marshal(user, user_fields) }

    def delete(self, id):
        user = filter(lambda t: t['id_usuario'] == id, users)
        if len(user) == 0:
            abort(404)
        users.remove(user[0])
        return { 'result': True }


api.add_resource(UserListAPI, '/tfg/api/v1.0/users', endpoint = 'users')
api.add_resource(UserAPI, '/tfg/api/v1.0/users/<int:id>', endpoint = 'user')
