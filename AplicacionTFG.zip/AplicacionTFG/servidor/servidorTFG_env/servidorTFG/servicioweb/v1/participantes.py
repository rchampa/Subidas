# -*- encoding: utf-8 -*-
from myglobal import app,db,api,auth

from flask import session, make_response, jsonify, abort
from flask.views import MethodView
from flask.ext.restful import Api, Resource, reqparse, fields, marshal
#import json,ast

from datetime import datetime 
from models import ViajeFuturo, Participante, Usuario,Amigos
from formatOutputMessage import formatOutput
   
#'actualizado_en': datetime.strptime("2014-11-30 10:30:00","%Y-%m-%d %H:%M:%S"), 

participante_fields = {
    'id_viaje': fields.Integer,
    'id_usuario': fields.Integer
}


class ParticipantesListAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('id_viaje', type = int, required = True, help = 'Falta el parametro id_viaje', location = 'json')
        self.reqparse.add_argument('id_usuario', type = int, required = True, help = 'Falta el parametro id_usuario', location = 'json')
        super(ParticipantesListAPI, self).__init__()
        
        #viajes?id_usuario=23
    def get(self):
        return ""

    #Da de alta un nuevo viaje y además añade al creador como participante del viaje
    def post(self):
        args = self.reqparse.parse_args()

        usuario = Usuario.query.filter_by(id_usuario=args['id_usuario']).first()
        viaje = ViajeFuturo.query.filter_by(id_viaje=args['id_viaje']).first()
        
        participante = Participante(usuario,viaje)
        db.session.add(participante)

        db.session.commit()

        content = { 'participante': marshal(participante,participante_fields)}
        return formatOutput(4000, content), 201

    
            


api.add_resource(ParticipantesListAPI, '/tfg/api/v1.0/participantes', endpoint = 'participantes')

