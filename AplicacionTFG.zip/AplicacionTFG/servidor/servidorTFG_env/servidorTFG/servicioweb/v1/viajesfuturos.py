# -*- encoding: utf-8 -*-
from myglobal import app,db,api,auth

from flask import session, make_response, jsonify, abort
from flask.views import MethodView
from flask.ext.restful import Api, Resource, reqparse, fields, marshal
#import json,ast

from datetime import datetime 
from models import ViajeFuturo
from formatOutputMessage import formatOutput
   
#'actualizado_en': datetime.strptime("2014-11-30 10:30:00","%Y-%m-%d %H:%M:%S"), 

viaje_fields = {
    'id_viaje': fields.Integer,
    'nombre': fields.String,
    'fecha_ini': fields.DateTime(dt_format='iso8601'),
    'duracion': fields.Integer,
    'categoria': fields.Integer,
    'pais': fields.String,
    'latitud': fields.Float,
    'longitud': fields.Float
}


class ViajesFuturosListAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('nombre', type = str, required = True, help = 'Falta el parametro nombre', location = 'json')
        self.reqparse.add_argument('pais', type = str, required = True, help = 'Falta el parametro pais', location = 'json')
        self.reqparse.add_argument('duracion', type = str, required = True, help = 'Falta el parametro duracion', location = 'json')
        self.reqparse.add_argument('categoria', type = str, required = True, help = 'Falta el parametro categoria', location = 'json')
        self.reqparse.add_argument('latitud', type = float, required = True, help = 'Falta el parametro latitud', location = 'json')
        self.reqparse.add_argument('longitud', type = float, required = True, help = 'Falta el parametro longitud', location = 'json')
        #self.reqparse.add_argument('fecha_nacimiento', type = datetime, required = True, help = 'Falta el parametro fecha_nacimiento', location = 'json')
        super(ViajesFuturosListAPI, self).__init__()
        
    def get(self):
        lista_viajes = ViajeFuturo.query.all()
        content = { 'viajes': map(lambda t: marshal(t, viaje_fields), lista_viajes) }
        return formatOutput(2000, content), 200

    def post(self):
        args = self.reqparse.parse_args()
        #nombre,duracion,categoria,pais,latitud,longitud)
        nuevo_viaje = ViajeFuturo(args['nombre'], args['duracion'], args['categoria'], args['pais'], args['latitud'], args['longitud'])
        db.session.add(nuevo_viaje)
        db.session.commit()
        content = { 'viaje': marshal(nuevo_viaje,viaje_fields)}
        return formatOutput(2001, content), 201

    
            

class ViajeFuturoAPI(Resource):
    decorators = [auth.login_required]
    
    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        #self.reqparse.add_argument('gcm_id', type = str, required = True, help = 'No gcm_id provided', location = 'json')
        super(ViajeFuturoAPI, self).__init__()

    def get(self, id):
        user = Usuario.query.filter_by(id_usuario=id).first()
        if user is not None:
            content = { 'user': marshal(user, user_fields) }
            return formatOutput(1002,content),200
        else:
            return formatOutput(1003), 200
        
    def put(self, id):
        user = filter(lambda t: t['id_usuario'] == id, users)
        if len(user) == 0:
            abort(404)
        user = user[0]
        args = self.reqparse.parse_args()
        for k, v in args.iteritems():
            if v != None:
                user[k] = v

        return { 'user': marshal(user, user_fields) }

    def delete(self, id):
        user = filter(lambda t: t['id_usuario'] == id, users)
        if len(user) == 0:
            abort(404)
        users.remove(user[0])
        return { 'result': True }


api.add_resource(ViajesFuturosListAPI, '/tfg/api/v1.0/viajes', endpoint = 'viajes')
api.add_resource(ViajeFuturoAPI, '/tfg/api/v1.0/viajes/<int:id>', endpoint = 'viaje')
