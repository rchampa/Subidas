
from myglobal import app

import routes

import servicioweb.v1.users
import servicioweb.v1.viajesfuturos
import servicioweb.v1.amigos
import servicioweb.v1.participantes
import servicioweb.v1.viajesrealizados

# import os
# from flask import Flask, request, flash, url_for, redirect, \
# render_template, abort, send_from_directory, \
# session, make_response, jsonify


# app = Flask(__name__)
# app.config.from_pyfile('flaskapp.cfg')
# from constants import MYSQL_URI
# app.config['SQLALCHEMY_DATABASE_URI'] = MYSQL_URI


# @app.route('/')
# def index():
#     return 'Hello World!'

# @app.route('/<path:resource>')
# def serveStaticResource(resource):
#     return send_from_directory('static/', resource)



# #Importing forms, preventing a CSRF attack
# from forms import SignupForm, SigninForm
# from models import db, Administrador
# db.init_app(app)


# @app.route('/testdb')
# def testdb():
#   if db.session.query("1").from_statement("SELECT 1").all():
#     return 'It works.'
#   else:
#     return 'Something is broken.'





# @app.route("/test")
# def test():
#     return "<strong>It's Alive!</strong>"

#     if __name__ == '__main__':
#         app.run()