print "just called once :)"

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

from flask import Flask
app = Flask(__name__)
app.config.from_pyfile('flaskapp.cfg')

#Base de datos MySQL
from flask.ext.sqlalchemy import SQLAlchemy
db = SQLAlchemy(app)
from constants import MYSQL_URI
app.config['SQLALCHEMY_DATABASE_URI'] = MYSQL_URI

#Servicios web
from flask.ext.restful import Api
from flask.ext.restful.representations.json import output_json
output_json.func_globals['settings'] = {'ensure_ascii': False, 'encoding': 'utf8'}
api = Api(app, catch_all_404s=True)

#Autenticacion BasicAuth
from flask.ext.httpauth import HTTPBasicAuth
auth = HTTPBasicAuth()

@auth.verify_password
def verify_pw(username, password):
	from models import Administrador
	admin = Administrador.query.filter_by(email = username).first()
	return (admin and admin.check_password(password))
 
@auth.error_handler
def unauthorized():
	from flask import make_response, jsonify
	return make_response(jsonify( { 'mensaje': 'Acceso no autorizado' } ), 403)
    # return 403 instead of 401 to prevent browsers from displaying the default auth dialog
