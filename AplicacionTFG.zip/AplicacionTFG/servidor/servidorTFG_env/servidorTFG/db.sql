create table administradores
(
    email varchar(64) primary key,
    password_hash text,
    creado_en datetime,
    actualizado_en datetime,
    estado integer, # 0 no validado, 1 validado, 2 administrador supremo
    ultima_conexion datetime
);

create table usuarios
(
    id_usuario int(11) primary key AUTO_INCREMENT,
    nombre_usuario varchar(60),
    password_usuario varchar(20),
    fecha_nacimiento datetime,
    creado_en datetime,
    actualizado_en datetime,
    ultima_conexion datetime
);

create table amigos
(
    id_amistad int(11) primary key AUTO_INCREMENT,
    id_amigo1 int(11),
    id_amigo2 int(11),
    FOREIGN KEY (id_amigo1) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_amigo2) REFERENCES usuarios(id_usuario),
    CONSTRAINT amistad UNIQUE (id_amigo1,id_amigo2)
);

create table viajes_futuros
(
    id_viaje int(11) primary key AUTO_INCREMENT,
    nombre varchar(40),
    fecha_ini datetime,
    duracion int,
    categoria int(2),
    pais varchar(40),
    latitud double,
    longitud double,
    realizado boolean
);

create table participantes
(
    id_viaje int(11),
    id_usuario int(11),
    FOREIGN KEY (id_viaje) REFERENCES viajes_futuros(id_viaje),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    primary key(id_viaje,id_usuario)
);