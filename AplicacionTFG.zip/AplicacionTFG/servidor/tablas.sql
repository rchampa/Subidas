create table viajes_futuros
(
    id_viaje int(11) primary key AUTO_INCREMENT,
    nombre varchar(40),
    fecha_ini timestamp,
    duracion int,
    categoria int(2),
    pais varchar(40),
    latitud double,
    longitud double
);

create table participantes
(
    id_viaje int(11),
    id_usuario int(11),
    FOREIGN KEY (id_viaje) REFERENCES viajes_futuros(id_viaje),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    primary key(id_viaje,id_usuario)
)