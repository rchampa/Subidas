x = 10
y = 20

if x<y:
	print "y es mayor que x"
else:
	print "X es mayo que y"

i = 0;
while i<100:
	print str(i)
	i=i+1
	