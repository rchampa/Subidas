package tfg.pedro.es.aplicaciontfg;

import android.app.Application;
import android.content.Context;
import android.util.Log;


/**
 * Esta clase permite tener acceder en cualquier momento
 * y desde cualquier clase al contexto de la aplicación
 */
public class MyApp extends Application {

    private static final String TAG = MyApp.class.getSimpleName();
    private static MyApp INSTANCE;


    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "MyApp.onCreate was called");
        INSTANCE = this;
    }

    public static Context getContext() {
        return INSTANCE.getApplicationContext();
    }
}
