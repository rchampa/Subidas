package tfg.pedro.es.aplicaciontfg.model.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import tfg.pedro.es.aplicaciontfg.model.vo.Amigo;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;
import tfg.pedro.es.aplicaciontfg.model.vo.ViajeAmigo;

/**
 * Created by Ricardo on 16/01/15.
 */
public class ViajeAmigoDAO {

    public static final String TABLE = "viajes_amigos";
    public static final String ID_VIAJE = "id_viaje";
    public static final String NOMBRE = "nombre";
    public static final String FECHA = "fecha";
    public static final String CATEGORIA = "categoria";
    public static final String PAIS = "pais";
    public static final String LATITUD = "latitud";
    public static final String LONGITUD = "longitud";
    public static final String ID_AMISTAD = "id_amistad";
    public static final String ID_AMIGO = "id_amigo";
    public static final String NOMBRE_AMIGO = "nombre_amigo";


    /*public ViajeRealizadoDAO(){
    }*/

    public long insert(Viaje viaje, Amigo amigo) {
        SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ID_VIAJE, viaje.getID());
        values.put(NOMBRE, viaje.getNombre());
        values.put(FECHA, viaje.getFecha());
        values.put(CATEGORIA, viaje.getCategoria().ordinal());
        values.put(PAIS, viaje.getPais());
        values.put(LATITUD, viaje.getLatitud());
        values.put(LONGITUD, viaje.getLongitud());

        values.put(ID_AMISTAD, amigo.getId_amistad());
        values.put(ID_AMIGO, amigo.getId_amigo());
        values.put(NOMBRE_AMIGO, amigo.getNombre());

        long num = db.insert(TABLE, null, values);
        db.close();
        return num;
    }



    /*public Viaje getViaje(int id) {

        SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
        //"select * from viajes
        // where id=?"
        String id_consultar = ""+id;
        Cursor cursor = db.query(TABLE, null, ID + "=?", new String[] { id_consultar }, null, null, null);
        Viaje viaje=null;

        if (cursor.moveToFirst()) {

            String nombre = cursor.getString(cursor.getColumnIndex(NOMBRE));
            String fecha = cursor.getString(cursor.getColumnIndex(FECHA));
            int categoria = cursor.getInt(cursor.getColumnIndex(CATEGORIA));
            Categoria cat = Categoria.values()[categoria];
            String pais = cursor.getString(cursor.getColumnIndex(PAIS));
            double latitud = cursor.getDouble(cursor.getColumnIndex(LATITUD));
            double longitud = cursor.getDouble(cursor.getColumnIndex(LONGITUD));


            viaje = new Viaje(id,nombre,fecha,cat,pais,latitud,longitud);

        }

        cursor.close();
        db.close();
        return viaje;
    }
*/

    public ArrayList<ViajeAmigo> getViajes() {

        ArrayList<ViajeAmigo> list = new ArrayList<ViajeAmigo>();
        SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
        //select * from viajes
        Cursor cursor = db.query(TABLE, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {

            ViajeAmigo viaje_amigo;
            Viaje viaje;
            Amigo amigo;
            do {
                int id = cursor.getInt(cursor.getColumnIndex(ID_VIAJE));
                String nombre = cursor.getString(cursor.getColumnIndex(NOMBRE));
                String fecha = cursor.getString(cursor.getColumnIndex(FECHA));
                int categoria = cursor.getInt(cursor.getColumnIndex(CATEGORIA));
                Categoria cat = Categoria.values()[categoria];
                String pais = cursor.getString(cursor.getColumnIndex(PAIS));
                double latitud = cursor.getDouble(cursor.getColumnIndex(LATITUD));
                double longitud = cursor.getDouble(cursor.getColumnIndex(LONGITUD));
                viaje = new Viaje(id,nombre,fecha,cat,pais,latitud,longitud);

                int id_amistad = cursor.getInt(cursor.getColumnIndex(ID_AMISTAD));
                int id_amigo = cursor.getInt(cursor.getColumnIndex(ID_AMIGO));
                String nombre_amigo = cursor.getString(cursor.getColumnIndex(NOMBRE_AMIGO));
                amigo = new Amigo(id_amistad,id_amigo,nombre_amigo);

                viaje_amigo = new ViajeAmigo(viaje,amigo);
                list.add(viaje_amigo);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    public ArrayList<ViajeAmigo> getViajes(int id_amigo) {

        ArrayList<ViajeAmigo> list = new ArrayList<ViajeAmigo>();
        SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
        //select * from viajes
        //Cursor cursor = db.query(TABLE, null, null, null, null, null, null);
        Cursor cursor = db.query(TABLE, null, ID_AMIGO + "=?", new String[] { ""+id_amigo }, null, null, null);

        if (cursor.moveToFirst()) {

            ViajeAmigo viaje_amigo;
            Viaje viaje;
            Amigo amigo;
            do {
                int id = cursor.getInt(cursor.getColumnIndex(ID_VIAJE));
                String nombre = cursor.getString(cursor.getColumnIndex(NOMBRE));
                String fecha = cursor.getString(cursor.getColumnIndex(FECHA));
                int categoria = cursor.getInt(cursor.getColumnIndex(CATEGORIA));
                Categoria cat = Categoria.values()[categoria];
                String pais = cursor.getString(cursor.getColumnIndex(PAIS));
                double latitud = cursor.getDouble(cursor.getColumnIndex(LATITUD));
                double longitud = cursor.getDouble(cursor.getColumnIndex(LONGITUD));
                viaje = new Viaje(id,nombre,fecha,cat,pais,latitud,longitud);

                int id_amistad = cursor.getInt(cursor.getColumnIndex(ID_AMISTAD));
                //int id_amigo = cursor.getInt(cursor.getColumnIndex(ID_AMIGO));
                String nombre_amigo = cursor.getString(cursor.getColumnIndex(NOMBRE_AMIGO));
                amigo = new Amigo(id_amistad,id_amigo,nombre_amigo);

                viaje_amigo = new ViajeAmigo(viaje,amigo);
                list.add(viaje_amigo);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    public void deleteAll() {
        SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
        db.delete(TABLE, null, null);
        db.close();
    }
}
