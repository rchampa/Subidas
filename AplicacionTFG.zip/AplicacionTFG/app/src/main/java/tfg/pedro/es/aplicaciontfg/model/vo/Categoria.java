package tfg.pedro.es.aplicaciontfg.model.vo;

/**
 * Created by Ricardo on 16/01/15.
 */
public enum Categoria {

    NEGOCIO,OCIO,FAMILIAR
}
