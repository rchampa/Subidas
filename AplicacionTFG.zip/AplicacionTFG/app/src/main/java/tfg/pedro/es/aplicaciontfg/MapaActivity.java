package tfg.pedro.es.aplicaciontfg;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import tfg.pedro.es.aplicaciontfg.model.dao.ViajeFuturoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 06/02/15.
 */
public class MapaActivity extends FragmentActivity {

    private GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_mapa);
        setUpMapIfNeeded();



        Bundle extras = getIntent().getExtras();
        if (extras != null) {

            String desde = extras.getString("desde");
            LatLng posicion = null;
            String pais="";

            if(desde.equals("realizados")){
                int id = extras.getInt("id");

                ViajeRealizadoDAO dao = new ViajeRealizadoDAO();
                Viaje v = dao.getViaje(id);
                pais = v.getPais();

                posicion = new LatLng(v.getLatitud(), v.getLongitud());

            }
            else{
                int id = extras.getInt("id");

                ViajeFuturoDAO dao = new ViajeFuturoDAO();
                Viaje v = dao.getViaje(id);
                pais = v.getPais();

                posicion = new LatLng(v.getLatitud(), v.getLongitud());
            }


            map.addMarker(new MarkerOptions().position(posicion).title(pais));

            CameraPosition camPos = new CameraPosition.Builder()
                    .target(posicion)   //Center camera in 'Plaza Maestro Villa'
                    .zoom(9)         //Set 15 level zoom
                            //.bearing(45)      //Set the orientation to northeast
                            //.tilt(70)         //Set 70 degrees tilt
                    .build();

            CameraUpdate camUpd3 = CameraUpdateFactory.newCameraPosition(camPos);
            map.animateCamera(camUpd3);



        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (map == null) {
            // Try to obtain the map from the SupportMapFragment.
            map = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();

            map.getUiSettings().setZoomControlsEnabled(true);
            map.getUiSettings().setCompassEnabled(true);

        }
    }



}
