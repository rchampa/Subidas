package tfg.pedro.es.aplicaciontfg.model.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 16/01/15.
 */
public class ViajeFuturoDAO {

    public static final String TABLE = "viajes_futuros";
    public static final String ID = "id";
    public static final String NOMBRE = "nombre";
    public static final String FECHA = "fecha";
    public static final String CATEGORIA = "categoria";
    public static final String PAIS = "pais";
    public static final String LATITUD = "latitud";
    public static final String LONGITUD = "longitud";

    /*public ViajeRealizadoDAO(){
    }*/

    public long insert(Viaje viaje) {
        SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
        ContentValues values = new ContentValues();
        //values.put(ID, viaje.getID());
        values.put(NOMBRE, viaje.getNombre());
        values.put(FECHA, viaje.getFecha());
        values.put(CATEGORIA, viaje.getCategoria().ordinal());
        values.put(PAIS, viaje.getPais());
        values.put(LATITUD, viaje.getLatitud());
        values.put(LONGITUD, viaje.getLongitud());

        long num = db.insert(TABLE, null, values);
        db.close();
        return num;
    }



    public Viaje getViaje(int id) {

        SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
        //"select * from viajes
        // where id=?"
        String id_consultar = ""+id;
        Cursor cursor = db.query(TABLE, null, ID + "=?", new String[] { id_consultar }, null, null, null);
        Viaje viaje=null;

        if (cursor.moveToFirst()) {

            String nombre = cursor.getString(cursor.getColumnIndex(NOMBRE));
            String fecha = cursor.getString(cursor.getColumnIndex(FECHA));
            int categoria = cursor.getInt(cursor.getColumnIndex(CATEGORIA));
            Categoria cat = Categoria.values()[categoria];
            String pais = cursor.getString(cursor.getColumnIndex(PAIS));
            double latitud = cursor.getDouble(cursor.getColumnIndex(LATITUD));
            double longitud = cursor.getDouble(cursor.getColumnIndex(LONGITUD));


            viaje = new Viaje(id,nombre,fecha,cat,pais,latitud,longitud);

        }

        cursor.close();
        db.close();
        return viaje;
    }


    public ArrayList<Viaje> getViajes() {

        ArrayList<Viaje> list = new ArrayList<Viaje>();
        SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
        //select * from viajes
        Cursor cursor = db.query(TABLE, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {

            Viaje viaje;
            do {
                int id = cursor.getInt(cursor.getColumnIndex(ID));
                String nombre = cursor.getString(cursor.getColumnIndex(NOMBRE));
                String fecha = cursor.getString(cursor.getColumnIndex(FECHA));
                int categoria = cursor.getInt(cursor.getColumnIndex(CATEGORIA));
                Categoria cat = Categoria.values()[categoria];

                String pais = cursor.getString(cursor.getColumnIndex(PAIS));
                double latitud = cursor.getDouble(cursor.getColumnIndex(LATITUD));
                double longitud = cursor.getDouble(cursor.getColumnIndex(LONGITUD));


                viaje = new Viaje(id,nombre,fecha,cat,pais,latitud,longitud);

                list.add(viaje);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    public boolean delete(int id) {
        SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
        int n = db.delete(TABLE, ID+"=?", new String[]{""+id});
        db.close();

        return n>0;
    }


/*
    public int update(Usuario usuario) {
        SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ID_USUARIO, usuario.getId_usuario());
        values.put(ID_CENTRO, usuario.getId_centro());
        values.put(ID_DISPOSITIVO, usuario.getId_dispositivo());
        values.put(NOMBRE, usuario.getNombre());
        values.put(APELLIDOS, usuario.getApellidos());
        values.put(EDAD, usuario.getEdad());
        values.put(FOTO, usuario.getFoto());
        int num = db.update(TABLE, values, ID_USUARIO + "=?",	new String[] { ""+usuario.getId_usuario() });

        db.close();
        return num;
    }

    public void deleteAll() {
        SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
        db.delete(TABLE, null, null);
        db.close();
    }
    */
}
