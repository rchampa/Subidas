package tfg.pedro.es.aplicaciontfg.tools;

import android.content.Context;
import android.content.SharedPreferences;

import tfg.pedro.es.aplicaciontfg.MyApp;

/**
 * Created by Ricardo on 09/04/15.
 */
public class MyGlobals {


    private static final String FILE_PREFERENCES = "mytfg";
    private static final String ID_USUARIO = "id_usuario";


    public static int getIDUsuario(){
        SharedPreferences prefs = MyApp.getContext().getSharedPreferences(FILE_PREFERENCES, Context.MODE_PRIVATE);
        int restoredID = prefs.getInt(ID_USUARIO, -1);
        return restoredID;
    }
    public static void saveIDUsuario(int id_usuario){
        SharedPreferences prefs = MyApp.getContext().getSharedPreferences(FILE_PREFERENCES,Context.MODE_PRIVATE);
        prefs.edit().putInt(ID_USUARIO, id_usuario).commit();
    }

    /*

    public static String getGCM_ID(){
        SharedPreferences prefs = MyApp.getContext().getSharedPreferences(FILE_PREFERENCES,Context.MODE_PRIVATE);
        String restoredText = prefs.getString(ID_GCM, null);
        return restoredText;
    }
    public static void saveGCM_ID(String gcm_id){
        SharedPreferences prefs = MyApp.getContext().getSharedPreferences(FILE_PREFERENCES,Context.MODE_PRIVATE);
        prefs.edit().putString(ID_GCM, gcm_id).commit();
    }
    */


}
