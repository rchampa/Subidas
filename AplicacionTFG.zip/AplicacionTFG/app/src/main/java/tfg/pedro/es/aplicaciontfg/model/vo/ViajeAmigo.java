package tfg.pedro.es.aplicaciontfg.model.vo;

/**
 * Created by Ricardo on 14/05/15.
 *
 * "categoria": 1,
 "duracion": 10,
 "fecha_ini": "2015-07-01T09:00:00+00:00",
 "id_amigo": 1,
 "id_viaje": 3,
 "latitud": 40.4343077,
 "longitud": -3.7126203,
 "nombre": "Viaje a Londres",
 "nombre_amigo": "Pepito",
 "pais": "Inglaterra"
 */
public class ViajeAmigo {
    private Viaje viaje;
    private Amigo amigo;

    public ViajeAmigo(Viaje v, Amigo a){
        this.amigo = a;
        this.viaje = v;
    }

    public Viaje getViaje() {
        return viaje;
    }

    public Amigo getAmigo() {
        return amigo;
    }

}
