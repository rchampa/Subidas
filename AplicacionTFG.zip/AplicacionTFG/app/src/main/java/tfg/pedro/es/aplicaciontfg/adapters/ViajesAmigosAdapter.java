package tfg.pedro.es.aplicaciontfg.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import tfg.pedro.es.aplicaciontfg.R;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;
import tfg.pedro.es.aplicaciontfg.model.vo.ViajeAmigo;

/**
 * Created by Ricardo on 16/01/15.
 */
public class ViajesAmigosAdapter extends BaseAdapter {

    private List<ViajeAmigo> mItems = new ArrayList<ViajeAmigo>();
    private Activity activity;

    public ViajesAmigosAdapter(Activity activity, List<ViajeAmigo> list) {
        this.activity = activity;
        mItems = list;
    }

    @Override
    public int getCount() {
        return mItems.size();
    }

    @Override
    public Object getItem(int position) {
        return mItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        ViajeAmigo v = mItems.get(position);
        return v.getViaje().getID();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        //View v = convertView;

        LayoutInflater vi = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = vi.inflate(R.layout.fila_viaje_amigo, parent, false);

        ViajeAmigo viaje = mItems.get(position);


        final int id = viaje.getViaje().getID();
        final String pais = viaje.getViaje().getPais();
        final String nombre = viaje.getViaje().getNombre();
        final String fecha = viaje.getViaje().getFecha();
        final String nombre_amigo = viaje.getAmigo().getNombre();

        TextView tv_pais = (TextView) v.findViewById(R.id.tv_pais);
        TextView tv_nombre = (TextView) v.findViewById(R.id.tv_nombre);
        TextView tv_fecha = (TextView) v.findViewById(R.id.tv_fecha);
        TextView tv_nombre_amigo = (TextView) v.findViewById(R.id.tv_nombre_amigo);

        tv_pais.setText(pais);
        tv_nombre.setText(nombre);
        tv_fecha.setText(fecha);
        tv_nombre_amigo.setText(nombre_amigo);


        return v;
    }


}
