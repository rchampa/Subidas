package tfg.pedro.es.aplicaciontfg.api;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;

import tfg.pedro.es.aplicaciontfg.tools.MyGlobals;

/**
 * Created by Ricardo on 18/05/15.
 */
public class APIParticipante extends Servidor{

    private String URI_PARTICIPANTES =HOST+"tfg/api/v1.0/participantes";


    public boolean apuntarseAViaje(int id_viaje){

        try {

            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost postRequest = new HttpPost(URI_PARTICIPANTES);
            postRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
            postRequest.addHeader("accept", "application/json; charset=utf-8");

            JSONObject json_object = new JSONObject();
            json_object.put("id_usuario", MyGlobals.getIDUsuario());
            json_object.put("id_viaje", id_viaje);


            StringEntity input = new StringEntity(json_object.toString());
            input.setContentType("application/json; charset=utf-8");
            postRequest.setEntity(input);

            HttpResponse response = httpClient.execute(postRequest);

            int http_status = response.getStatusLine().getStatusCode();
            if ( http_status == 200 || http_status == 201) {

                HttpEntity entity = response.getEntity();
                httpClient.getConnectionManager().shutdown();
                if (entity != null) {

                    String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                    JSONObject json_response;
                    try {
                        json_response = new JSONObject(jsonText);
                        Respuesta respuesta = new Respuesta(json_response);

                        if(respuesta.getCode()==4000){
                            return true;
                        }
                        else{
                            return false;
                        }



                    }
                    catch (JSONException e) {
                        return false;
                    }
                    catch (Exception e) {
                        return false;
                    }

                }
                else {
                    return false;
                }
            }
            else{
                return false;
            }


        } catch (MalformedURLException e) {
            return false;
        } catch (Exception e) {
            return false;
        }

    }
}
