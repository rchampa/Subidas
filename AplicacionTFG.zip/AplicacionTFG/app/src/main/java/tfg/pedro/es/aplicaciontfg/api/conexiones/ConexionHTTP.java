package tfg.pedro.es.aplicaciontfg.api.conexiones;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;


    public abstract class ConexionHTTP extends AsyncTask<Void,Void,Void>{

        protected ProgressDialog progressDialog;
        protected String titulo,mensaje;
        private Context context;

        public ConexionHTTP(Context context){
            this.context = context;
        }
        public ConexionHTTP(Fragment fragment){
            this.context = fragment.getActivity();
        }

        protected void onPreExecute() {

            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage(this.mensaje);
            progressDialog.setTitle(this.titulo);
            progressDialog.setCancelable(false);            //show(context,titulo, mensaje);
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(Void... params) {
            doInBackground();
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            progressDialog.dismiss();
            onPostExecute();
        }

        protected abstract void doInBackground();
        protected abstract void onPostExecute();


    }
