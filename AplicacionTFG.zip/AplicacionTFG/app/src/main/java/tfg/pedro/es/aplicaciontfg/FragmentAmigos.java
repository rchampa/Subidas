package tfg.pedro.es.aplicaciontfg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import tfg.pedro.es.aplicaciontfg.adapters.AmigosAdapter;
import tfg.pedro.es.aplicaciontfg.api.APIAmigos;
import tfg.pedro.es.aplicaciontfg.api.conexiones.ConexionHTTP;
import tfg.pedro.es.aplicaciontfg.model.dao.AmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Amigo;

/**
 * Created by Ricardo on 16/01/15.
 */
public class FragmentAmigos extends Fragment {

    ListView lista;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {

        View fragment_layout = inflater.inflate(R.layout.fragment_amigos, container, false);
        setHasOptionsMenu(true);

        lista = (ListView)fragment_layout.findViewById(R.id.lista_amigos);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(FragmentAmigos.this.getActivity(), ViajesAmigosActivity.class);
                intent.putExtra("ID_AMIGO",""+id);
                startActivity(intent);
            }
        });

        return fragment_layout;
    }


    @Override
    public void onResume(){
        super.onResume();
        GetAmistades conexion = new GetAmistades();
        conexion.execute();
    }

    /*
    @Override
    public void onResume(){
        super.onResume();

        AmigoDAO dao = new AmigoDAO();
        List<Amigo> amigos = dao.getAmigos();


        AmigosAdapter adapter = new AmigosAdapter(this.getActivity(), amigos);
        lista.setAdapter(adapter);

    }

*/

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu,inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_add:
                Intent intent = new Intent(FragmentAmigos.this.getActivity(), NuevoAmigoActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private class GetAmistades extends ConexionHTTP {

        int id_amigo;
        boolean ok;

        public GetAmistades(){
            super(FragmentAmigos.this);
            super.titulo = "Amistad";
            super.mensaje = "Comprobando datos de usuario...";

            this.id_amigo = id_amigo;

        }

        protected void doInBackground(){

            APIAmigos api = new APIAmigos();
            this.ok = api.getAmigos();
        }
        protected void onPostExecute(){

            if(this.ok){
                Toast.makeText(context, "Syncronización correcta", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(context, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }

            AmigoDAO dao = new AmigoDAO();
            List<Amigo> amigos = dao.getAmigos();

            AmigosAdapter adapter = new AmigosAdapter(FragmentAmigos.this.getActivity(), amigos);
            lista.setAdapter(adapter);

        }
    }
}
