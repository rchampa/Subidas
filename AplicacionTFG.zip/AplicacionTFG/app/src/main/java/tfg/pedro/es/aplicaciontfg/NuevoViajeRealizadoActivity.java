package tfg.pedro.es.aplicaciontfg;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 19/02/15.
 */
public class NuevoViajeRealizadoActivity extends ActionBarActivity{

    private Button bt_anadir;
    private EditText nombre,fecha;
    private Spinner categorias;
    private AutoCompleteTextView actv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_viaje_realizado);

        String[] countries = getResources().getStringArray(R.array.lista_paises);
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,countries);


        actv = (AutoCompleteTextView) findViewById(R.id.et_pais);
        actv.setAdapter(adapter);

        this.setTitle("Nuevo viaje");


        nombre = (EditText)findViewById(R.id.et_nombre);
        fecha = (EditText)findViewById(R.id.et_fecha);

        categorias = (Spinner)findViewById(R.id.sp_categorias);

        bt_anadir = (Button)findViewById(R.id.bt_anadir);
        bt_anadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nombre_viaje = nombre.getText().toString();
                String fecha_viaje = fecha.getText().toString();
                String pais = actv.getText().toString();

                int index_categoria = categorias.getSelectedItemPosition();
                Categoria cat;

                if(index_categoria==0){
                    cat = Categoria.FAMILIAR;
                }
                else if(index_categoria==1){
                    cat = Categoria.OCIO;
                }
                else{
                    cat = Categoria.NEGOCIO;
                }

                LatLng posicion =  Tools.getLocationFromAddress(NuevoViajeRealizadoActivity.this, pais);

                if(posicion!=null){
                    Viaje viaje = new Viaje(nombre_viaje,fecha_viaje,cat,pais,posicion.latitude,posicion.longitude,true);
                    ViajeRealizadoDAO dao = new ViajeRealizadoDAO();
                    dao.insert(viaje);
                    Toast.makeText(NuevoViajeRealizadoActivity.this, "Nuevo viaje añadido", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(NuevoViajeRealizadoActivity.this, "No se ha podido añadir el viaje", Toast.LENGTH_SHORT).show();
                }




                NuevoViajeRealizadoActivity.this.finish();

            }
        });
    }
}
