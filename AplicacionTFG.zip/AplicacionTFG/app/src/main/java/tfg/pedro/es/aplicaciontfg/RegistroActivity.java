package tfg.pedro.es.aplicaciontfg;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import tfg.pedro.es.aplicaciontfg.api.APIUsuarios;
import tfg.pedro.es.aplicaciontfg.api.conexiones.ConexionHTTP;

/**
 * Created by Ricardo on 09/04/15.
 */
public class RegistroActivity extends Activity {


    private Button bt_registro;
    private EditText et_nombre_usuario, et_password_usuario;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        et_nombre_usuario = (EditText)findViewById(R.id.et_nombre_usuario);
        et_password_usuario = (EditText)findViewById(R.id.et_password_usuario);

        bt_registro = (Button)findViewById(R.id.bt_registro);


        bt_registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String usuario = et_nombre_usuario.getText().toString();
                String password = et_password_usuario.getText().toString();

                RegistroUsuarioHTTP conexion = new RegistroUsuarioHTTP("Registro", "Registrando nuevo usuario",usuario,password);
                conexion.execute();
            }
        });
    }

    private class RegistroUsuarioHTTP extends ConexionHTTP{

        String usuario,password;
        boolean ok;

        public RegistroUsuarioHTTP(String titulo, String mensaje, String usuario, String password){
            super(RegistroActivity.this);
            super.titulo = titulo;
            super.mensaje = mensaje;

            this.usuario = usuario;
            this.password = password;

        }

        protected void doInBackground(){

            APIUsuarios api = new APIUsuarios();
            this.ok = api.registrarUsuario(usuario,password);
        }
        protected void onPostExecute(){

            if(this.ok){
                Toast.makeText(RegistroActivity.this, "Usuario registrado.",Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(RegistroActivity.this, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }

        }
    }


}
