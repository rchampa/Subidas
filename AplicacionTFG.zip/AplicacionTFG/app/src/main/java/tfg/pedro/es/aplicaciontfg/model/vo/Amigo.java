package tfg.pedro.es.aplicaciontfg.model.vo;

/**
 * Created by Ricardo on 19/04/15.
 */
public class Amigo {

    private int id_amistad;
    private int id_amigo;
    private String nombre;

    public Amigo(int id_amistad, int id_amigo, String nombre) {
        this.id_amistad = id_amistad;
        this.id_amigo = id_amigo;
        this.nombre = nombre;
    }

    public int getId_amistad() {
        return id_amistad;
    }

    public int getId_amigo() {
        return id_amigo;
    }

    public String getNombre() {
        return nombre;
    }
}
