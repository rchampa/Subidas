package tfg.pedro.es.aplicaciontfg.api;

import android.util.Base64;

/**
 * Created by Ricardo on 09/04/15.
 */
public class Servidor {


    protected final String HOST = "http://192.168.1.101:5000/";


    protected String getB64Auth (String login, String pass) {
        String source=login+":"+pass;
        String ret="Basic "+ Base64.encodeToString(source.getBytes(), Base64.URL_SAFE | Base64.NO_WRAP);
        return ret;
    }
}
