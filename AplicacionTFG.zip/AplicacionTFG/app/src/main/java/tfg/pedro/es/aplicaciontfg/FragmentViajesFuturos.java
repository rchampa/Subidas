package tfg.pedro.es.aplicaciontfg;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import tfg.pedro.es.aplicaciontfg.adapters.ViajesAdapter;
import tfg.pedro.es.aplicaciontfg.api.APIViajes;
import tfg.pedro.es.aplicaciontfg.api.conexiones.ConexionHTTP;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeFuturoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;


public class FragmentViajesFuturos extends Fragment {

    ListView lista;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {

        View fragment_layout = inflater.inflate(R.layout.fragment_viajes_futuros, container, false);
        setHasOptionsMenu(true);

        lista = (ListView)fragment_layout.findViewById(R.id.lista_viajes_futuros);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, final long id) {



                new AlertDialog.Builder(FragmentViajesFuturos.this.getActivity())
                .setTitle("Viajes futuros")
                .setMessage("Elige una opción")
                .setPositiveButton(R.string.option_map, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(FragmentViajesFuturos.this.getActivity(), MapaActivity.class);
                        i.putExtra("desde", "futuros");
                        i.putExtra("id", (int) id);
                        startActivity(i);
                    }
                })
                .setNegativeButton(R.string.option_marcar, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {


                        MarcarViajeRealizado conexion = new MarcarViajeRealizado((int)id);
                        conexion.execute();

                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();



            }
        });

        return fragment_layout;
    }

    @Override
    public void onResume(){
        super.onResume();

        GetViajes conexion = new GetViajes();
        conexion.execute();
        //refrescarLista();

    }

    private void refrescarLista(){
        ViajeFuturoDAO dao = new ViajeFuturoDAO();
        List<Viaje> viajes = dao.getViajes();


        ViajesAdapter adapter = new ViajesAdapter(this.getActivity(), viajes);
        lista.setAdapter(adapter);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu,inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_add:
                Intent intent = new Intent(FragmentViajesFuturos.this.getActivity(), NuevoViajeFuturoActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private class GetViajes extends ConexionHTTP {

        boolean ok;

        public GetViajes(){
            super(FragmentViajesFuturos.this.getActivity());
            super.titulo = "Amistad";
            super.mensaje = "Comprobando datos...";

        }

        protected void doInBackground(){

            APIViajes api = new APIViajes();
            this.ok= api.getViajesFuturos();

        }
        protected void onPostExecute(){

            if(this.ok){
                Toast.makeText(context, "Syncronización correcta", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(context, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }

            refrescarLista();

        }
    }

    private class MarcarViajeRealizado extends ConexionHTTP {

        boolean ok;
        int id_viaje;

        public MarcarViajeRealizado(int id_viaje){
            super(FragmentViajesFuturos.this.getActivity());
            super.titulo = "Viaje";
            super.mensaje = "Marcando como realizado...";
            this.id_viaje = id_viaje;
        }

        protected void doInBackground(){

            APIViajes api = new APIViajes();
            this.ok= api.marcarComoRealizado(id_viaje);

        }
        protected void onPostExecute(){

            if(this.ok){

                ViajeFuturoDAO dao = new ViajeFuturoDAO();
                Viaje v = dao.getViaje(id_viaje);
                boolean ok = dao.delete(id_viaje);

                if(ok){
                    ViajeRealizadoDAO dao_realizado = new ViajeRealizadoDAO();
                    v.setRealizado(true);
                    dao_realizado.insert(v);

                    refrescarLista();
                }
                else{
                    Toast.makeText(FragmentViajesFuturos.this.getActivity(),"No se ha podido borrar", Toast.LENGTH_SHORT).show();
                }

                Toast.makeText(context, "Syncronización correcta", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(context, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }

            refrescarLista();

        }
    }
}
