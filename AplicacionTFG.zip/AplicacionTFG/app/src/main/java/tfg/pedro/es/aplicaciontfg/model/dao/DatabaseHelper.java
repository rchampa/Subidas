package tfg.pedro.es.aplicaciontfg.model.dao;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import tfg.pedro.es.aplicaciontfg.MyApp;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "viajes.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper() {
        super(MyApp.getContext(),DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //"create table nombre_tabla ( id integer, nombre text, fecha text, categoria integer )"
        db.execSQL("create table " + ViajeRealizadoDAO.TABLE + " ("
                + ViajeRealizadoDAO.ID + " integer primary key AUTOINCREMENT,"
                + ViajeRealizadoDAO.NOMBRE + " text,"
                + ViajeRealizadoDAO.FECHA + " text,"
                + ViajeRealizadoDAO.CATEGORIA + " integer)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }


}

