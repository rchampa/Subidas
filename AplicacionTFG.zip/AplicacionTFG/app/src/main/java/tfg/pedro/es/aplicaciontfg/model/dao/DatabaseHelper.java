package tfg.pedro.es.aplicaciontfg.model.dao;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import tfg.pedro.es.aplicaciontfg.MyApp;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "viajes.db";
    private static final int DATABASE_VERSION = 3;

    public DatabaseHelper() {
        super(MyApp.getContext(),DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //"create table nombre_tabla ( id integer, nombre text, fecha text, categoria integer )"
        db.execSQL("create table " + ViajeRealizadoDAO.TABLE + " ("
                + ViajeRealizadoDAO.ID + " integer primary key AUTOINCREMENT,"
                + ViajeRealizadoDAO.NOMBRE + " text,"
                + ViajeRealizadoDAO.FECHA + " text,"
                + ViajeRealizadoDAO.PAIS + " text,"
                + ViajeRealizadoDAO.LATITUD + " double,"
                + ViajeRealizadoDAO.LONGITUD + " double,"
                + ViajeRealizadoDAO.CATEGORIA + " integer)");


        db.execSQL("create table " + ViajeFuturoDAO.TABLE + " ("
                + ViajeFuturoDAO.ID + " integer primary key AUTOINCREMENT,"
                + ViajeFuturoDAO.NOMBRE + " text,"
                + ViajeFuturoDAO.FECHA + " text,"
                + ViajeFuturoDAO.PAIS + " text,"
                + ViajeFuturoDAO.LATITUD + " double,"
                + ViajeFuturoDAO.LONGITUD + " double,"
                + ViajeFuturoDAO.CATEGORIA + " integer)");

        db.execSQL("create table " + AmigoDAO.TABLE + " ("
                + AmigoDAO.ID + " integer,"
                + AmigoDAO.ID_AMIGO + " integer,"
                + AmigoDAO.NOMBRE + " text)");

        db.execSQL("create table " + ViajeAmigoDAO.TABLE + " ("
                + ViajeAmigoDAO.ID_VIAJE + " integer,"
                + ViajeAmigoDAO.ID_AMISTAD + " integer,"
                + ViajeAmigoDAO.ID_AMIGO + " integer,"
                + ViajeAmigoDAO.NOMBRE_AMIGO + " text,"
                + ViajeAmigoDAO.NOMBRE + " text,"
                + ViajeAmigoDAO.FECHA + " text,"
                + ViajeAmigoDAO.PAIS + " text,"
                + ViajeAmigoDAO.LATITUD + " double,"
                + ViajeAmigoDAO.LONGITUD + " double,"
                + ViajeAmigoDAO.CATEGORIA + " integer)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }


}

