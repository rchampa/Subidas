package tfg.pedro.es.aplicaciontfg.model.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import tfg.pedro.es.aplicaciontfg.model.vo.Amigo;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 19/04/15.
 */
public class AmigoDAO {

    public static final String TABLE = "amigos";
    public static final String ID = "id_amistad";
    public static final String ID_AMIGO = "id_amigo";
    public static final String NOMBRE = "nombre";

    public long insert(Amigo amigo) {
        SQLiteDatabase db = new DatabaseHelper().getWritableDatabase();
        ContentValues values = new ContentValues();
        //values.put(ID, viaje.getID());
        values.put(NOMBRE, amigo.getNombre());
        values.put(ID, amigo.getId_amistad());
        values.put(ID_AMIGO, amigo.getId_amigo());

        long num = db.insert(TABLE, null, values);
        db.close();
        return num;
    }



    public Amigo getAmigo(int id_amigo) {

        SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
        String id_consultar = ""+id_amigo;
        Cursor cursor = db.query(TABLE, null, ID_AMIGO + "=?", new String[] { id_consultar }, null, null, null);
        Amigo amigo=null;

        if (cursor.moveToFirst()) {

            String nombre = cursor.getString(cursor.getColumnIndex(NOMBRE));
            int id_amistad = cursor.getInt(cursor.getColumnIndex(ID));
            amigo = new Amigo(id_amistad,id_amigo,nombre);

        }

        cursor.close();
        db.close();
        return amigo;
    }


    public ArrayList<Amigo> getAmigos() {

        ArrayList<Amigo> list = new ArrayList<Amigo>();
        SQLiteDatabase db = new DatabaseHelper().getReadableDatabase();
        Cursor cursor = db.query(TABLE, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {

            Amigo amigo;
            do {
                String nombre = cursor.getString(cursor.getColumnIndex(NOMBRE));
                int id_amistad = cursor.getInt(cursor.getColumnIndex(ID));
                int id_amigo = cursor.getInt(cursor.getColumnIndex(ID_AMIGO));
                amigo = new Amigo(id_amistad,id_amigo,nombre);

                list.add(amigo);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

}
