package tfg.pedro.es.aplicaciontfg.api;

import android.net.Uri;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;

import tfg.pedro.es.aplicaciontfg.model.dao.AmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeAmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeFuturoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Amigo;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;
import tfg.pedro.es.aplicaciontfg.tools.MyGlobals;

/**
 * Created by Ricardo on 19/04/15.
 */
public class APIViajes extends Servidor{

    private String URI_VIAJES ="tfg/api/v1.0/viajes";
    private String URI_NUEVO_VIAJE =HOST+"tfg/api/v1.0/viajes";


    public boolean getViajes(){

        try {


            DefaultHttpClient httpClient = new DefaultHttpClient();
            Uri.Builder uri = Uri.parse(HOST).buildUpon();
            uri.path(URI_VIAJES)
            .appendQueryParameter("id_usuario", ""+MyGlobals.getIDUsuario())
            .build();

            String url = uri.toString();
            HttpGet getRequest = new HttpGet(url);
            getRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
            getRequest.addHeader("accept", "application/json; charset=utf-8");

            HttpResponse response = httpClient.execute(getRequest);

            int http_status = response.getStatusLine().getStatusCode();
            if ( http_status == 200 || http_status == 201) {

                HttpEntity entity = response.getEntity();
                //httpClient.getConnectionManager().shutdown();
                if (entity != null) {

                    String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                    JSONObject json_response;
                    try {
                        json_response = new JSONObject(jsonText);
                        Respuesta respuesta = new Respuesta(json_response);

                        if(respuesta.getCode()==2005){

                            JSONObject content = respuesta.getContent();
                            JSONArray viajes = content.getJSONArray("viajes");

                            ViajeFuturoDAO dao = new ViajeFuturoDAO();
                            dao.deleteAll();
                            for(int i=0; i< viajes.length(); i++){
                                JSONObject json = viajes.getJSONObject(i);
                                Categoria cat = Categoria.values()[json.getInt("categoria")];
                                Viaje viaje = new Viaje(json.getInt("id_viaje"), json.getString("nombre"), json.getString("fecha_ini"),
                                        cat, json.getString("pais"), json.getDouble("latitud"),json.getDouble("longitud"));

                                dao.insert(viaje);
                            }




                            return true;
                        }
                        else{
                            return false;
                        }



                    }
                    catch (JSONException e) {
                        return false;
                    }
                    catch (Exception e) {
                        return false;
                    }

                }
                else {
                    return false;
                }
            }
            else{
                return false;
            }


        } catch (MalformedURLException e) {
            return false;
        } catch (Exception e) {
            return false;
        }

    }


    public boolean crearNuevoViaje(Viaje viaje){

        try {

            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost postRequest = new HttpPost(URI_NUEVO_VIAJE);
            postRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
            postRequest.addHeader("accept", "application/json; charset=utf-8");

            JSONObject json_object = new JSONObject();
            json_object.put("id_usuario", MyGlobals.getIDUsuario());
            json_object.put("nombre", viaje.getNombre());
            json_object.put("pais", viaje.getPais());
            json_object.put("duracion", 10);
            json_object.put("categoria", viaje.getCategoria().ordinal());
            json_object.put("latitud", viaje.getLatitud());
            json_object.put("longitud", viaje.getLongitud());
            json_object.put("fecha_ini", viaje.getFecha()+" 09:00:00");//debe tener este formato %Y-%m-%d %H:%M:%S


            StringEntity input = new StringEntity(json_object.toString());
            input.setContentType("application/json; charset=utf-8");
            postRequest.setEntity(input);

            HttpResponse response = httpClient.execute(postRequest);

            int http_status = response.getStatusLine().getStatusCode();
            if ( http_status == 200 || http_status == 201) {

                HttpEntity entity = response.getEntity();
                httpClient.getConnectionManager().shutdown();
                if (entity != null) {

                    String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                    JSONObject json_response;
                    try {
                        json_response = new JSONObject(jsonText);
                        Respuesta respuesta = new Respuesta(json_response);

                        if(respuesta.getCode()==2001){
                            return true;
                        }
                        else{
                            return false;
                        }



                    }
                    catch (JSONException e) {
                        return false;
                    }
                    catch (Exception e) {
                        return false;
                    }

                }
                else {
                    return false;
                }
            }
            else{
                return false;
            }


        } catch (MalformedURLException e) {
            return false;
        } catch (Exception e) {
            return false;
        }

    }

}
