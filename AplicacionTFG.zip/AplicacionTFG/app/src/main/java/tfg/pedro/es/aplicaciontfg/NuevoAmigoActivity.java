package tfg.pedro.es.aplicaciontfg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import tfg.pedro.es.aplicaciontfg.api.APIAmigos;
import tfg.pedro.es.aplicaciontfg.api.APIUsuarios;
import tfg.pedro.es.aplicaciontfg.api.conexiones.ConexionHTTP;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 19/02/15.
 */
public class NuevoAmigoActivity extends ActionBarActivity{

    private Button bt_anadir;
    private EditText et_id_amigo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_amigo);

        this.setTitle("Nueva amistad");


        et_id_amigo = (EditText)findViewById(R.id.et_amigo);

        bt_anadir = (Button)findViewById(R.id.bt_anadir);
        bt_anadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id_amigo = Integer.parseInt(et_id_amigo.getText().toString().trim());

                NuevoAmigoHTTP conexion = new NuevoAmigoHTTP(id_amigo);
                conexion.execute();

            }
        });
    }



    private class NuevoAmigoHTTP extends ConexionHTTP {

        int id_amigo;
        boolean ok;

        public NuevoAmigoHTTP(int id_amigo){
            super(NuevoAmigoActivity.this);
            super.titulo = "Amistad";
            super.mensaje = "Comprobando datos de usuario...";

            this.id_amigo = id_amigo;

        }

        protected void doInBackground(){

            APIAmigos api = new APIAmigos();
            this.ok = api.nuevaAmistad(this.id_amigo);
        }
        protected void onPostExecute(){

            if(this.ok){
                Toast.makeText(context, "Amistad correcto.", Toast.LENGTH_SHORT).show();
                finish();

            }
            else{
                Toast.makeText(context, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }

        }
    }
}
