package tfg.pedro.es.aplicaciontfg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

import tfg.pedro.es.aplicaciontfg.model.dao.ViajeFuturoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 19/02/15.
 */
public class ViajesAmigosActivity extends ActionBarActivity{

    private Button bt_anadir;
    private EditText nombre,fecha;
    private Spinner categorias;
    private AutoCompleteTextView actv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_amigo);
    }

    @Override
    public void onResume(){
        super.onResume();


        //ViajesAdapter adapter = new ViajesAdapter(this, viajes);
        //lista.setAdapter(adapter);
    }

}
