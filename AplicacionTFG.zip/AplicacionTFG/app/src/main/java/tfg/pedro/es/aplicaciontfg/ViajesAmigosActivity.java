package tfg.pedro.es.aplicaciontfg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

import tfg.pedro.es.aplicaciontfg.api.APIAmigos;
import tfg.pedro.es.aplicaciontfg.api.APIParticipante;
import tfg.pedro.es.aplicaciontfg.api.conexiones.ConexionHTTP;
import tfg.pedro.es.aplicaciontfg.model.dao.AmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeAmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeFuturoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Amigo;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;
import tfg.pedro.es.aplicaciontfg.model.vo.ViajeAmigo;

/**
 * Created by Ricardo on 19/02/15.
 */
public class ViajesAmigosActivity extends ActionBarActivity{

    ListView lista;
    int id_amigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viajes_amigos);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String ID = extras.getString("ID_AMIGO");
            id_amigo = Integer.parseInt(ID);
        }

        lista = (ListView)findViewById(R.id.lista_viajes_amigos);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {

                //ViajeAmigo va = (ViajeAmigo)adapter.getSelectedItem();

                ApuntarseViaje conexion = new ApuntarseViaje((int)id);
                conexion.execute();
            }
        });
    }

    @Override
    public void onResume(){
        super.onResume();
        GetViajesAmigos conexion = new GetViajesAmigos();
        conexion.execute();
    }


    private class GetViajesAmigos extends ConexionHTTP {

        boolean ok;

        public GetViajesAmigos(){
            super(ViajesAmigosActivity.this);
            super.titulo = "Amistad";
            super.mensaje = "Comprobando datos...";

        }

        protected void doInBackground(){

            APIAmigos api = new APIAmigos();
            this.ok = api.getViajesAmigos();
        }
        protected void onPostExecute(){

            if(this.ok){
                Toast.makeText(context, "Syncronización correcta", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(context, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }

            ViajeAmigoDAO dao = new ViajeAmigoDAO();
            List<ViajeAmigo> viajes = dao.getViajes(id_amigo);

            ViajesAmigosAdapter adapter = new ViajesAmigosAdapter(ViajesAmigosActivity.this, viajes);
            lista.setAdapter(adapter);

        }
    }

    private class ApuntarseViaje extends ConexionHTTP {

        boolean ok;
        int id_viaje;

        public ApuntarseViaje(int id_viaje){
            super(ViajesAmigosActivity.this);
            super.titulo = "Apuntarse";
            super.mensaje = "Comprobando datos...";
            this.id_viaje = id_viaje;

        }

        protected void doInBackground(){

            APIParticipante api = new APIParticipante();
            this.ok = api.apuntarseAViaje(id_viaje);
        }
        protected void onPostExecute(){

            if(this.ok){
                Toast.makeText(context, "Te has apuntado al viaje!", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(context, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }

            ViajeAmigoDAO dao = new ViajeAmigoDAO();
            List<ViajeAmigo> viajes = dao.getViajes(id_amigo);

            ViajesAmigosAdapter adapter = new ViajesAmigosAdapter(ViajesAmigosActivity.this, viajes);
            lista.setAdapter(adapter);

        }
    }

}
