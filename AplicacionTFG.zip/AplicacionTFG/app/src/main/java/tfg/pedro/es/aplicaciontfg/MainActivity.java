package tfg.pedro.es.aplicaciontfg;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.widget.Toast;

import tfg.pedro.es.aplicaciontfg.model.dao.AmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeAmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeFuturoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.tools.MyGlobals;


public class MainActivity extends ActionBarActivity {


    private String[] opcionesMenu;
    private DrawerLayout drawerLayout;
    private ListView drawerList;
    private ActionBarDrawerToggle drawerToggle;

    private CharSequence tituloSeccion;
    private CharSequence tituloApp;

    private boolean doubleBackToExitPressedOnce;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        opcionesMenu = new String[] {"Home","Viajes realizados", "Viajes futuros", "Mapa", "Amigos","Cerrar sesión"};
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawerList = (ListView) findViewById(R.id.left_drawer);


        ArrayAdapter adapter = new ArrayAdapter<String>(
                getSupportActionBar().getThemedContext(),
                android.R.layout.simple_list_item_1, opcionesMenu);

        drawerList.setAdapter(adapter);

        drawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Fragment fragment = null;

                switch (position) {
                    case 0:
                        fragment = new FragmentHome();
                        break;
                    case 1:
                        fragment = new FragmentViajesRealizados();
                        break;
                    case 2:
                        fragment = new FragmentViajesFuturos();
                        break;
                    case 3:
                        fragment = new FragmentMapa();
                        break;
                    case 4:
                        fragment = new FragmentAmigos();
                        break;

                    case 5:
                        //cerrar sesion
                        MyGlobals.saveIDUsuario(-1);
                        new AmigoDAO().deleteAll();
                        new ViajeAmigoDAO().deleteAll();
                        new ViajeFuturoDAO().deleteAll();
                        new ViajeRealizadoDAO().deleteAll();
                        finish();
                        Intent intent;
                        intent = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(intent);
                        return;
                }

                cambiarFragment(fragment);


                drawerList.setItemChecked(position, true);

                tituloSeccion = opcionesMenu[position];
                getSupportActionBar().setTitle(tituloSeccion);

                drawerLayout.closeDrawer(drawerList);
            }
        });

        tituloSeccion = getTitle();
        tituloApp = getTitle();

        drawerToggle = new ActionBarDrawerToggle(this,
                drawerLayout,
//                R.drawable.ic_navigation_drawer,
                R.string.drawer_abierto,
                R.string.drawer_cerrado) {

            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle(tituloSeccion);
                ActivityCompat.invalidateOptionsMenu(MainActivity.this);
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle(tituloApp);
                ActivityCompat.invalidateOptionsMenu(MainActivity.this);
            }
        };

        drawerLayout.setDrawerListener(drawerToggle);

        // enable ActionBar app icon to behave as action to toggle nav drawer
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        drawerToggle.syncState();

        cambiarFragment(new FragmentHome());

    }

    private void cambiarFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();

        fragmentManager.beginTransaction()
                .replace(R.id.content_frame, fragment)
                .commit();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Presiona atrás de nuevo para salir", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }
}
