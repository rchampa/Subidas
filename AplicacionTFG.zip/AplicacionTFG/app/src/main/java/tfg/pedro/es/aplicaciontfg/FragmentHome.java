package tfg.pedro.es.aplicaciontfg;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import tfg.pedro.es.aplicaciontfg.adapters.ViajesAdapter;
import tfg.pedro.es.aplicaciontfg.adapters.ViajesAmigosAdapter;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeAmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeFuturoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;
import tfg.pedro.es.aplicaciontfg.model.vo.ViajeAmigo;


public class FragmentHome extends Fragment {

    ListView ultimos_viajes_realizados,viajes_visitados_amigos;
    TextView tv_paises_visitados;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {

        View fragment_layout = inflater.inflate(R.layout.fragment_home, container, false);
        setHasOptionsMenu(true);

        ultimos_viajes_realizados = (ListView)fragment_layout.findViewById(R.id.ultimos_viajes_realizados);
        viajes_visitados_amigos = (ListView)fragment_layout.findViewById(R.id.viajes_visitados_amigos);
        tv_paises_visitados = (TextView)fragment_layout.findViewById(R.id.tv_paises_visitados);

        return fragment_layout;
    }

    @Override
    public void onResume(){
        super.onResume();

        ViajeRealizadoDAO dao1 = new ViajeRealizadoDAO();
        ArrayList<Viaje> viajes1 = dao1.getViajes();
        ArrayList<Viaje> viajes_realizados = new ArrayList<Viaje>();
        for(int i=viajes1.size()-1, j=0; i>=0 && j<3; i--,j++){
            Viaje viaje = viajes1.get(i);
            viajes_realizados.add(viaje);
        }

        ViajesAdapter adapter1 = new ViajesAdapter(this.getActivity(),viajes_realizados);
        ultimos_viajes_realizados.setAdapter(adapter1);

        ViajeAmigoDAO dao2 = new ViajeAmigoDAO();
        List<ViajeAmigo> viajes2 = dao2.getViajes();
        ArrayList<ViajeAmigo> viajes_visitados = new ArrayList<ViajeAmigo>();
        for(int i=viajes2.size()-1, j=0; i>=0 && j<3; i--,j++){
            ViajeAmigo viaje = viajes2.get(i);
            viajes_visitados.add(viaje);
        }

        ViajesAmigosAdapter adapter2 = new ViajesAmigosAdapter(this.getActivity(), viajes_visitados);
        viajes_visitados_amigos.setAdapter(adapter2);

        int num_paises = dao1.getPaisesVisitados();
        if(num_paises == 1)
            tv_paises_visitados.setText(num_paises+" país visitado");
        else
            tv_paises_visitados.setText(num_paises+" países visitados");

    }



}
