package tfg.pedro.es.aplicaciontfg.api;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Ricardo on 09/04/15.
 */
public class Respuesta {

    private int code;
    private String message;
    private JSONObject content;

    public Respuesta(JSONObject json_response) throws JSONException {
        code = json_response.getInt("code");
        message =  json_response.getString("message");
        content = json_response.getJSONObject("content");
    }
    public int getCode() {
        return code;
    }
    public String getMessage() {
        return message;
    }
    public JSONObject getContent() {
        return content;
    }
}
