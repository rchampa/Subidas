package tfg.pedro.es.aplicaciontfg;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

import tfg.pedro.es.aplicaciontfg.api.APIParticipante;
import tfg.pedro.es.aplicaciontfg.api.APIViajes;
import tfg.pedro.es.aplicaciontfg.api.conexiones.ConexionHTTP;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeAmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeFuturoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;
import tfg.pedro.es.aplicaciontfg.model.vo.ViajeAmigo;

/**
 * Created by Ricardo on 19/02/15.
 */
public class NuevoViajeFuturoActivity extends ActionBarActivity{

    private Button bt_anadir;
    private EditText nombre,fecha;
    private Spinner categorias;
    private AutoCompleteTextView actv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_viaje_futuro);

        String[] countries = getResources().getStringArray(R.array.lista_paises);
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,countries);


        actv = (AutoCompleteTextView) findViewById(R.id.et_pais);
        actv.setAdapter(adapter);

        this.setTitle("Nuevo viaje");


        nombre = (EditText)findViewById(R.id.et_nombre);
        fecha = (EditText)findViewById(R.id.et_fecha);

        categorias = (Spinner)findViewById(R.id.sp_categorias);

        bt_anadir = (Button)findViewById(R.id.bt_anadir);
        bt_anadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nombre_viaje = nombre.getText().toString();
                String fecha_viaje = fecha.getText().toString();
                String pais = actv.getText().toString();

                int index_categoria = categorias.getSelectedItemPosition();
                Categoria cat;

                if(index_categoria==0){
                    cat = Categoria.FAMILIAR;
                }
                else if(index_categoria==1){
                    cat = Categoria.OCIO;
                }
                else{
                    cat = Categoria.NEGOCIO;
                }

                Viaje viaje = new Viaje(nombre_viaje,fecha_viaje,cat,pais,0d,0d, false);
                //ViajeFuturoDAO dao = new ViajeFuturoDAO();
                //dao.insert(viaje);

                CrearNuevoViaje conexion = new CrearNuevoViaje(viaje);
                conexion.execute();

                //Toast.makeText(NuevoViajeFuturoActivity.this, "Nuevo viaje añadido", Toast.LENGTH_SHORT).show();


                NuevoViajeFuturoActivity.this.finish();

            }
        });
    }


    private class CrearNuevoViaje extends ConexionHTTP {

        boolean ok;
        Viaje viaje;

        public CrearNuevoViaje(Viaje viaje){
            super(NuevoViajeFuturoActivity.this);
            super.titulo = "Viaje";
            super.mensaje = "Alta de nuevo viaje...";
            this.viaje = viaje;

        }

        protected void doInBackground(){

            APIViajes api = new APIViajes();
            this.ok = api.crearNuevoViaje(viaje);
        }
        protected void onPostExecute(){

            if(this.ok){
                Toast.makeText(context, "Nuevo viaje!", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(context, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }


        }
    }
}
