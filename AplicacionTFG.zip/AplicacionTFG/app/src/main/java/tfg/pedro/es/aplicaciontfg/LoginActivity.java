package tfg.pedro.es.aplicaciontfg;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import tfg.pedro.es.aplicaciontfg.api.APIUsuarios;
import tfg.pedro.es.aplicaciontfg.api.conexiones.ConexionHTTP;

/**
 * Created by Ricardo on 09/04/15.
 */
public class LoginActivity extends Activity {


    private Button bt_login, bt_registro;
    private EditText et_nombre_usuario, et_password_usuario;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et_nombre_usuario = (EditText)findViewById(R.id.et_nombre_usuario);
        et_password_usuario = (EditText)findViewById(R.id.et_password_usuario);

        bt_login = (Button)findViewById(R.id.bt_login);
        bt_registro = (Button)findViewById(R.id.bt_registro);


        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String usuario = et_nombre_usuario.getText().toString();
                String password = et_password_usuario.getText().toString();

                LoginUsuarioHTTP conexion = new LoginUsuarioHTTP(usuario,password);
                conexion.execute();

            }
        });


        bt_registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(LoginActivity.this, RegistroActivity.class);
                startActivity(intent);
            }
        });
    }


    private class LoginUsuarioHTTP extends ConexionHTTP {

        String usuario,password;
        boolean ok;

        public LoginUsuarioHTTP(String usuario, String password){
            super(LoginActivity.this);
            super.titulo = "Login";
            super.mensaje = "Comprobando datos de usuario...";

            this.usuario = usuario;
            this.password = password;

        }

        protected void doInBackground(){

            APIUsuarios api = new APIUsuarios();
            this.ok = api.loginUsuario(usuario, password);
        }
        protected void onPostExecute(){

            if(this.ok){
                Toast.makeText(LoginActivity.this, "Login correcto.", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(LoginActivity.this, "Ha ocurrido un error.",Toast.LENGTH_SHORT).show();
            }

        }
    }



}
