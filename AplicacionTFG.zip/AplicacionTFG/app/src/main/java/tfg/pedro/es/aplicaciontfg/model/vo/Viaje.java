package tfg.pedro.es.aplicaciontfg.model.vo;

/**
 * Created by Ricardo on 16/01/15.
 */
public class Viaje {

    private int id;
    private String nombre;
    private String fecha;
    private Categoria categoria;


    public Viaje(int id, String nombre, String fecha, Categoria categoria){
        this.id = id;
        this.nombre = nombre;
        this.fecha = fecha;
        this.categoria = categoria;
    }

    public int getID(){
        return this.id;
    }

    public String getNombre(){
        return  this.nombre;
    }

    public String getFecha(){
        return this.fecha;
    }

    public Categoria getCategoria(){
        return this.categoria;
    }
}
