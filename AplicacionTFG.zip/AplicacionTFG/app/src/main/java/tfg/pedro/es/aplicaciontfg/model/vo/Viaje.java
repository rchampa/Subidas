package tfg.pedro.es.aplicaciontfg.model.vo;

/**
 * Created by Ricardo on 16/01/15.
 */
public class Viaje {

    private int id;
    private String nombre;
    private String fecha;
    private Categoria categoria;
    private String pais;
    private double latitud;
    private double longitud;


    public Viaje(int id, String nombre, String fecha, Categoria categoria, String pais, double latitud, double longitud){
        this.id = id;
        this.nombre = nombre;
        this.fecha = fecha;
        this.categoria = categoria;
        this.pais = pais;
        this.latitud = latitud;
        this.longitud = longitud;
    }
    public Viaje(String nombre, String fecha, Categoria categoria, String pais, double latitud, double longitud){
        this.nombre = nombre;
        this.fecha = fecha;
        this.categoria = categoria;
        this.pais = pais;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public int getID(){
        return this.id;
    }

    public String getNombre(){
        return  this.nombre;
    }

    public String getFecha(){
        return this.fecha;
    }

    public Categoria getCategoria(){
        return this.categoria;
    }

    public String getPais(){
        return this.pais;
    }
    public double getLatitud(){
        return this.latitud;
    }
    public double getLongitud(){
        return this.longitud;
    }
}
