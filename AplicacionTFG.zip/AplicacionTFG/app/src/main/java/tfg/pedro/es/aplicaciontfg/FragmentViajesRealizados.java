package tfg.pedro.es.aplicaciontfg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 16/01/15.
 */
public class FragmentViajesRealizados extends Fragment {

    ListView lista;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {

        View fragment_layout = inflater.inflate(R.layout.fragment_viajes_realizados, container, false);
        setHasOptionsMenu(true);

        lista = (ListView)fragment_layout.findViewById(R.id.lista_viajes_realizados);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent i = new Intent(FragmentViajesRealizados.this.getActivity(), MapaActivity.class);
                i.putExtra("id",(int)id);
                startActivity(i);

            }
        });

        return fragment_layout;
    }

    @Override
    public void onResume(){
        super.onResume();

        ViajeRealizadoDAO dao = new ViajeRealizadoDAO();
        List<Viaje> viajes = dao.getViajes();


        ViajesAdapter adapter = new ViajesAdapter(this.getActivity(), viajes);
        lista.setAdapter(adapter);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu,inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_add:
                Intent intent = new Intent(FragmentViajesRealizados.this.getActivity(), NuevoViajeRealizadoActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
