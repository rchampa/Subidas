package tfg.pedro.es.aplicaciontfg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import tfg.pedro.es.aplicaciontfg.model.dao.ViajeRealizadoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 16/01/15.
 */
public class FragmentViajesRealizados extends Fragment {

    ListView lista;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {

        View fragment_layout = inflater.inflate(R.layout.fragment_viajes_realizados, container, false);

        lista = (ListView)fragment_layout.findViewById(R.id.lista_viajes_realizados);

        generarViajes();

        ViajeRealizadoDAO dao = new ViajeRealizadoDAO();
        List<Viaje> viajes = dao.getViajes();


        ViajesAdapter adapter = new ViajesAdapter(this.getActivity(), viajes);
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent i = new Intent(FragmentViajesRealizados.this.getActivity(), MapaActivity.class);
                i.putExtra("id",(int)id);
                startActivity(i);

            }
        });

        return fragment_layout;
    }


    private void generarViajes(){


        ViajeRealizadoDAO dao = new ViajeRealizadoDAO();

        Viaje v = new Viaje(0, "viaje1", "12/12/2014", Categoria.FAMILIAR,"España", 40.417325, -3.683081);
        Viaje v1 = new Viaje(0, "viaje2", "12/12/2015", Categoria.OCIO,"Francia",40.417325, -3.683081);
        Viaje v2 = new Viaje(0, "viaje3", "12/12/2016", Categoria.NEGOCIO,"Alemania",40.417325, -3.683081);
        Viaje v3 = new Viaje(0, "viaje4", "12/12/2017", Categoria.FAMILIAR,"Portugal",40.417325, -3.683081);

        dao.insert(v);
        dao.insert(v1);
        dao.insert(v2);
        dao.insert(v3);
    }
}
