package tfg.pedro.es.aplicaciontfg.api;

import android.net.Uri;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;

import tfg.pedro.es.aplicaciontfg.model.dao.AmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.dao.ViajeAmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Amigo;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;
import tfg.pedro.es.aplicaciontfg.model.vo.ViajeAmigo;
import tfg.pedro.es.aplicaciontfg.tools.MyGlobals;

/**
 * Created by Ricardo on 19/04/15.
 */
public class APIAmigos extends Servidor{

    private String URI_AMIGOS ="tfg/api/v1.0/friendships";
    private String URI_USUARIOS ="tfg/api/v1.0/users";
    private String URI_VIAJES ="tfg/api/v1.0/viajes";




    public boolean nuevaAmistad(int id_amigo){

        try {

            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost postRequest = new HttpPost(HOST+URI_AMIGOS);
            postRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
            postRequest.addHeader("accept", "application/json; charset=utf-8");

            JSONObject json_object = new JSONObject();
            json_object.put("id_amigo1", MyGlobals.getIDUsuario());
            json_object.put("id_amigo2", id_amigo);


            StringEntity input = new StringEntity(json_object.toString());
            input.setContentType("application/json; charset=utf-8");
            postRequest.setEntity(input);

            HttpResponse response = httpClient.execute(postRequest);

            int http_status = response.getStatusLine().getStatusCode();
            if ( http_status == 200 || http_status == 201) {

                /*
                HttpEntity entity = response.getEntity();
                //httpClient.getConnectionManager().shutdown();
                if (entity != null) {

                    String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                    JSONObject json_response;
                    try {
                        json_response = new JSONObject(jsonText);
                        Respuesta respuesta = new Respuesta(json_response);

                        if(respuesta.getCode()==3001){

                            JSONObject content = respuesta.getContent();
                            JSONObject amistades = content.getJSONObject("amistades");
                            int id_amistad = amistades.getInt("id_amistad");
                            int id_amigo2 = amistades.getInt("id_amigo2");

                            HttpGet getRequest = new HttpGet(URI_USUARIOS+"/"+id_amigo2);
                            getRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
                            getRequest.addHeader("accept", "application/json; charset=utf-8");
                            response = httpClient.execute(getRequest);

                            http_status = response.getStatusLine().getStatusCode();
                            if ( http_status == 200 || http_status == 201) {
                                entity = response.getEntity();
                                jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                                json_response = new JSONObject(jsonText);
                                respuesta = new Respuesta(json_response);
                                content = respuesta.getContent();
                                JSONObject user = content.getJSONObject("user");
                                String nombre_amigo = user.getString("nombre_usuario");

                                Amigo amigo = new Amigo(id_amistad,id_amigo2,nombre_amigo);
                                AmigoDAO dao = new AmigoDAO();
                                dao.insert(amigo);

                                return true;
                            }


                            return false;
                        }
                        else{
                            return false;
                        }



                    }
                    catch (JSONException e) {
                        return false;
                    }
                    catch (Exception e) {
                        return false;
                    }

                }
                else {
                    return false;
                }
                */

                return true;
            }
            else{
                return false;
            }


        } catch (MalformedURLException e) {
            return false;
        } catch (Exception e) {
            return false;
        }

    }



    public boolean getAmigos(){

        try {


            DefaultHttpClient httpClient = new DefaultHttpClient();
            Uri.Builder uri = Uri.parse(HOST).buildUpon();
            uri.path(URI_AMIGOS)
            .appendQueryParameter("id_usuario", ""+MyGlobals.getIDUsuario())
            .build();

            String url = uri.toString();
            HttpGet getRequest = new HttpGet(url);
            getRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
            getRequest.addHeader("accept", "application/json; charset=utf-8");

            HttpResponse response = httpClient.execute(getRequest);

            int http_status = response.getStatusLine().getStatusCode();
            if ( http_status == 200 || http_status == 201) {

                HttpEntity entity = response.getEntity();
                //httpClient.getConnectionManager().shutdown();
                if (entity != null) {

                    String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                    JSONObject json_response;
                    try {
                        json_response = new JSONObject(jsonText);
                        Respuesta respuesta = new Respuesta(json_response);

                        if(respuesta.getCode()==3004){

                            JSONObject content = respuesta.getContent();
                            JSONArray amigos = content.getJSONArray("amigos");

                            AmigoDAO dao = new AmigoDAO();
                            dao.deleteAll();
                            for(int i=0; i< amigos.length(); i++){
                                JSONObject a = amigos.getJSONObject(i);
                                Amigo amigo = new Amigo(0,a.getInt("id_usuario"),a.getString("nombre_usuario"));

                                dao.insert(amigo);
                            }




                            return true;
                        }
                        else{
                            return false;
                        }



                    }
                    catch (JSONException e) {
                        return false;
                    }
                    catch (Exception e) {
                        return false;
                    }

                }
                else {
                    return false;
                }
            }
            else{
                return false;
            }


        } catch (MalformedURLException e) {
            return false;
        } catch (Exception e) {
            return false;
        }

    }


    public boolean getViajesAmigos(){

        try {


            DefaultHttpClient httpClient = new DefaultHttpClient();
            Uri.Builder uri = Uri.parse(HOST).buildUpon();
            uri.path(URI_VIAJES)
            .appendQueryParameter("id_usuario", "" + MyGlobals.getIDUsuario())
            .appendQueryParameter("amigos", "" + true)
            .build();

            String url = uri.toString();
            HttpGet getRequest = new HttpGet(url);
            getRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
            getRequest.addHeader("accept", "application/json; charset=utf-8");

            HttpResponse response = httpClient.execute(getRequest);

            int http_status = response.getStatusLine().getStatusCode();
            if ( http_status == 200 || http_status == 201) {

                HttpEntity entity = response.getEntity();
                //httpClient.getConnectionManager().shutdown();
                if (entity != null) {

                    String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                    JSONObject json_response;
                    try {
                        json_response = new JSONObject(jsonText);
                        Respuesta respuesta = new Respuesta(json_response);

                        /**

                         "categoria": 1,
                         "duracion": 10,
                         "fecha_ini": "2015-07-01T09:00:00+00:00",
                         "id_amigo": 1,
                         "id_amistad": 19,
                         "id_viaje": 3,
                         "latitud": 40.4343077,
                         "longitud": -3.7126203,
                         "nombre": "Viaje a Londres",
                         "nombre_amigo": "Pepito",
                         "pais": "Inglaterra"

                         */

                        if(respuesta.getCode()==2004){

                            JSONObject content = respuesta.getContent();
                            JSONArray viajes = content.getJSONArray("viajes");

                            ViajeAmigoDAO dao = new ViajeAmigoDAO();
                            dao.deleteAll();
                            for(int i=0; i< viajes.length(); i++){
                                JSONObject a = viajes.getJSONObject(i);

                                int id_viaje = a.getInt("id_viaje");
                                int categoria = a.getInt("categoria");
                                Categoria cat = Categoria.values()[categoria];
                                int duracion = a.getInt("duracion");
                                String nombre = a.getString("nombre");
                                String pais = a.getString("pais");
                                String fecha_ini = a.getString("fecha_ini");
                                double latitud = a.getDouble("latitud");
                                double longitud = a.getDouble("longitud");

                                Viaje viaje = new Viaje(id_viaje,nombre,fecha_ini,cat,pais,latitud,longitud);
                                Amigo amigo = new Amigo(a.getInt("id_amistad"),a.getInt("id_amigo"),a.getString("nombre_amigo"));

                                dao.insert(viaje,amigo);
                            }




                            return true;
                        }
                        else{
                            return false;
                        }



                    }
                    catch (JSONException e) {
                        return false;
                    }
                    catch (Exception e) {
                        return false;
                    }

                }
                else {
                    return false;
                }
            }
            else{
                return false;
            }


        } catch (MalformedURLException e) {
            return false;
        } catch (Exception e) {
            return false;
        }

    }

}
