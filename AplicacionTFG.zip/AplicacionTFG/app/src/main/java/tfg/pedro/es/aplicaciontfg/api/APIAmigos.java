package tfg.pedro.es.aplicaciontfg.api;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;

import tfg.pedro.es.aplicaciontfg.model.dao.AmigoDAO;
import tfg.pedro.es.aplicaciontfg.model.vo.Amigo;
import tfg.pedro.es.aplicaciontfg.tools.MyGlobals;

/**
 * Created by Ricardo on 19/04/15.
 */
public class APIAmigos extends Servidor{

    private String URI_AMIGOS =HOST+"tfg/api/v1.0/friendships";
    private String URI_USUARIOS =HOST+"tfg/api/v1.0/users";



    public boolean nuevaAmistad(int id_amigo){

        try {

            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost postRequest = new HttpPost(URI_AMIGOS);
            postRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
            postRequest.addHeader("accept", "application/json; charset=utf-8");

            JSONObject json_object = new JSONObject();
            json_object.put("id_amigo1", MyGlobals.getIDUsuario());
            json_object.put("id_amigo2", id_amigo);


            StringEntity input = new StringEntity(json_object.toString());
            input.setContentType("application/json; charset=utf-8");
            postRequest.setEntity(input);

            HttpResponse response = httpClient.execute(postRequest);

            int http_status = response.getStatusLine().getStatusCode();
            if ( http_status == 200 || http_status == 201) {

                HttpEntity entity = response.getEntity();
                //httpClient.getConnectionManager().shutdown();
                if (entity != null) {

                    String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                    JSONObject json_response;
                    try {
                        json_response = new JSONObject(jsonText);
                        Respuesta respuesta = new Respuesta(json_response);

                        if(respuesta.getCode()==3001){

                            JSONObject content = respuesta.getContent();
                            JSONObject amistades = content.getJSONObject("amistades");
                            int id_amistad = amistades.getInt("id_amistad");
                            int id_amigo2 = amistades.getInt("id_amigo2");

                            HttpGet getRequest = new HttpGet(URI_USUARIOS+"/"+id_amigo2);
                            getRequest.setHeader("Authorization", getB64Auth("pedro@mail.com","1234"));
                            getRequest.addHeader("accept", "application/json; charset=utf-8");
                            response = httpClient.execute(getRequest);

                            http_status = response.getStatusLine().getStatusCode();
                            if ( http_status == 200 || http_status == 201) {
                                entity = response.getEntity();
                                jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                                json_response = new JSONObject(jsonText);
                                respuesta = new Respuesta(json_response);
                                content = respuesta.getContent();
                                JSONObject user = content.getJSONObject("user");
                                String nombre_amigo = user.getString("nombre_usuario");

                                Amigo amigo = new Amigo(id_amistad,id_amigo2,nombre_amigo);
                                AmigoDAO dao = new AmigoDAO();
                                dao.insert(amigo);

                                return true;
                            }


                            return false;
                        }
                        else{
                            return false;
                        }



                    }
                    catch (JSONException e) {
                        return false;
                    }
                    catch (Exception e) {
                        return false;
                    }

                }
                else {
                    return false;
                }
            }
            else{
                return false;
            }


        } catch (MalformedURLException e) {
            return false;
        } catch (Exception e) {
            return false;
        }

    }

}
