package tfg.pedro.es.aplicaciontfg.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import tfg.pedro.es.aplicaciontfg.R;
import tfg.pedro.es.aplicaciontfg.model.vo.Amigo;
import tfg.pedro.es.aplicaciontfg.model.vo.Categoria;
import tfg.pedro.es.aplicaciontfg.model.vo.Viaje;

/**
 * Created by Ricardo on 16/01/15.
 */
public class AmigosAdapter extends BaseAdapter {

    private List<Amigo> mItems = new ArrayList<Amigo>();
    private Activity activity;

    public AmigosAdapter(Activity activity, List<Amigo> list) {
        this.activity = activity;
        mItems = list;
    }

    @Override
    public int getCount() {
        return mItems.size();
    }

    @Override
    public Object getItem(int position) {
        return mItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        Amigo v = mItems.get(position);
        return v.getId_amigo();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        //View v = convertView;

        LayoutInflater vi = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = vi.inflate(R.layout.fila_amigo, parent, false);

        Amigo viaje = mItems.get(position);


        final int id = viaje.getId_amigo();
        final String nombre = viaje.getNombre();

        TextView tv_id_amigo = (TextView) v.findViewById(R.id.tv_id_amigo);
        TextView tv_nombre = (TextView) v.findViewById(R.id.tv_nombre);
        tv_id_amigo.setText(""+id);
        tv_nombre.setText(nombre);

        return v;
    }


}
