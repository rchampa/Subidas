package holamundo.ricardo.es.holamundoandroid;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity {

    EditText et_usuario;
    EditText et_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //..
        et_usuario = (EditText)findViewById(R.id.et_usuario);
        et_password = (EditText)findViewById(R.id.et_password);


        Button bt_login = (Button)findViewById(R.id.bt_login);


        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String usuario = et_usuario.getText().toString();
                String password = et_password.getText().toString();

                String mensaje = usuario + " " + password;

                Toast.makeText(MainActivity.this,mensaje,Toast.LENGTH_SHORT).show();

            }
        });


    }

}
