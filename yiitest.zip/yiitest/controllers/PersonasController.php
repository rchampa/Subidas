<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\AltaPersonaForm;
use app\models\ActualizarPersonaForm;


class PersonasController extends Controller
{
    
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }
    
    public function actionIndex()
    {
        $db = new \yii\db\Connection([
        'dsn' => 'mysql:host=localhost;port=3306;dbname=example',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        ]);
        $db->open();

        // return a set of rows. each row is an associative array of column names and values.
        // an empty array is returned if no results
        $personas = $db->createCommand('SELECT * FROM personas')
                    ->queryAll();
        
        $coches = $db->createCommand('SELECT * FROM coches')
                    ->queryAll();
        
        $data = array(
            "personas"=>$personas,
            "coches"=>$coches
            );
        
        $db->close();
        
        return $this->render('index',$data);
    }
    
    public function actionAlta(){
        
        $model = new AltaPersonaForm();
        if ($model->load(Yii::$app->request->post())) {
            Yii::$app->session->setFlash('formulario_enviado');
            
            $db = new \yii\db\Connection([
            'dsn' => 'mysql:host=localhost;port=3306;dbname=example',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
            ]);
            $db->open();
            
            $gen = $model->genero;
            if($gen=="masculino"){
                $genero = true;
            }
            else{
                $genero = false;
            }
            // INSERT (table name, column values)
            $db->createCommand()->insert('personas', [
                'nombre' => $model->nombre,
                'apellidos' => $model->apellidos,
                'edad' => $model->edad,
                'genero'=> $genero
            ])->execute();

            
            $db->close();
            

            return $this->refresh();
        } else {
        
            return $this->render('alta', [
                'model' => $model,
            ]);
        }
        
    }
    
    public function actionActualizar($id){
        
        $model = new ActualizarPersonaForm();
        if ($model->load(Yii::$app->request->post())) {
            Yii::$app->session->setFlash('formulario_enviado');
            
            $db = new \yii\db\Connection([
            'dsn' => 'mysql:host=localhost;port=3306;dbname=example',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
            ]);
            $db->open();
            
            $gen = $model->genero;
            if($gen=="masculino"){
                $genero = true;
            }
            else{
                $genero = false;
            }
            // INSERT (table name, column values)
            $db->createCommand()->update('UPDATE personas SET edad=:edad WHERE id=:id')
                 ->bindValue(':id', $id)
                 ->bindValue(':edad', $model->edad)
                 ->execute();

            
            $db->close();
            

            return $this->refresh();
        } else {
            
             $db = new \yii\db\Connection([
            'dsn' => 'mysql:host=localhost;port=3306;dbname=example',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
            ]);
            $db->open();

            // return a set of rows. each row is an associative array of column names and values.
            // an empty array is returned if no results
            $persona = $db->createCommand('SELECT * FROM personas where id=:id')
                    ->bindValue(':id', $id)
                    ->queryOne();
        
            $model->nombre = $persona['nombre'];
            $model->apellidos = $persona['apellidos'];
            $model->edad = $persona['edad'];
            $model->genero = $persona['nombre']? "masculino" : "femenino";
            return $this->render('actualizar', [
                'model' => $model,
            ]);
        }
        
    }
}