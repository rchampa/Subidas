<?php

namespace app\models;

use Yii;
use yii\base\Model;

/**
 * ContactForm is the model behind the contact form.
 */
class ActualizarPersonaForm extends Model
{
    public $nombre;
    public $apellidos;
    public $edad;
    public $genero;
    public $verifyCode;
    
    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            // name, email, subject and body are required
            [['nombre', 'edad', 'genero'], 'required'],
            // verifyCode needs to be entered correctly
            ['verifyCode', 'captcha'],
            [['nombre'], 'string'],
            [['apellidos'], 'string'],
            [['edad'], 'integer'],
            [['genero'], 'string'],
        ];
    }

    
    /**
     * @return array customized attribute labels
     */
    public function attributeLabels()
    {
        return [
            'verifyCode' => 'Código de verificación',
        ];
    }

}
