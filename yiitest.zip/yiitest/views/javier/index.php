<?php
/* @var $this yii\web\View */
$this->title = 'Controlador Javier';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Estamos en Javier/index!</h1>

        <p class="lead">You have successfully created your Yii-powered application.</p>

        
    </div>


</div>
