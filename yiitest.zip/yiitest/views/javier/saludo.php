<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
$this->title = 'Saludo';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1>Saludo</h1>

    <p>
        Esta es la paigina saludo.
    </p>

    
</div>
