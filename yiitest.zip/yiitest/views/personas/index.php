<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
$this->title = 'Saludo';
$this->params['breadcrumbs'][] = $this->title;
$data =  $_params_;

$lista_personas = $data['personas'];
$lista_coches = $data['coches'];


?>
<div class="site-about">
    <h1>Lista de personas</h1>

    <?php
        for($i=0;$i<count($lista_personas);$i++){
            $persona = $lista_personas[$i];
            echo $persona['nombre']."<br>";
        }
    
    ?>
    
    <h1>Lista de coches</h1>

    <?php
        for($i=0;$i<count($lista_coches);$i++){
            $coche = $lista_coches[$i];
            echo $coche['modelo']."<br>";
        }
    
    ?>

    
</div>
