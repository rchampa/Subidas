<?php
/* @var $this yii\web\View */
$this->title = 'Controlador Ricardo';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Estamos en Ricardo/index!</h1>

        <p class="lead">You have successfully created your Yii-powered application.</p>

        
    </div>


</div>
